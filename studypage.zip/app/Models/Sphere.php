<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sphere extends Model
{
    protected $table = 'sphere';
    protected $fillable = ['name_ru'];

}
