<?php
return[
    'bachelor_' => 'Колледж/Бакалавр',
    'bachelor' => 'Бакалавр',
    'college' => 'Колледж',
    'master_' => 'Магистратура/Докторантура',
    'master' => 'Магистратура',
    'second_higher' => '2-е высшее',
    'publications' => 'Публикации статей',
    'rating_he' => 'Рейтинг ВУЗов',
    'discipline' => 'По предмету',
    'specialty' => 'По специальности',
    'university' => 'По ВУЗу',
    'search' => 'Поиск',
    'login' => 'Вход',
    'register' => 'Регистрация',
    'error' => 'Ошибка!',
    'success' => 'Сохранено',
];