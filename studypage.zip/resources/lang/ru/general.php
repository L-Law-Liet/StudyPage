<?php
return[
    'bachelor' => 'Колледж/Бакалавр',
    'error' => 'Ошибка!',
    'success' => 'Сохранено',
];