<?php
return[
  'bachelor' => 'Колледж/Бакалавр',
];