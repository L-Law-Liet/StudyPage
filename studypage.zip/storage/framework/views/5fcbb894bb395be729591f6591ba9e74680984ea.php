<?php $__env->startSection('title', 'Просмотр профильного премета'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Просмотр профильного премета</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <table class="table table-striped table-view">
                        <tr>
                            <th>Дата создание</th>
                            <td><?php echo e(\Carbon\Carbon::parse($subject->created_at)->format('d.m.Y')); ?></td>
                        </tr>
                        <tr>
                            <th>Наименование</th>
                            <td><?php echo e($subject->name_ru); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>