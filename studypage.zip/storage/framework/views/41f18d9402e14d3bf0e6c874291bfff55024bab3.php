<?php $__env->startSection('title', 'Пользователи'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Пользователи</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-body">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th width="4%">#</th>
                            <th width="50%">ФИО</th>
                            <th width="12%" class="">Баланс</th>
                            <th width="12%" class="">Даты</th>
                            <th width="22%" colspan="2" class="text-center">Действия</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($users->firstItem()+$k); ?></td>
                                <td><?php echo e($v->name); ?></td>
                                <td><?php echo e($v->bill); ?></td>
                                <td><?php echo e($v->birthDate); ?></td>
                                <td>
                                    <a href="/admin/user/view/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                                    </a>
                                </td>
                                <td>
                                    <a class="nDBtn" data-href="/admin/user/delete/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td width="20%">Количество <?php echo e($count); ?></td>
                            <td class='text-center'><?php echo e($users->links()); ?></td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>