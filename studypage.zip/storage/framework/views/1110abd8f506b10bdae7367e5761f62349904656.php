<?php if(Session::has('flash_message')): ?>
    <div class="container">
        <div class="alert alert-success">
            <?php echo e(Session::get('flash_message')); ?>

        </div>
    </div>
<?php endif; ?>
<?php if(Session::has('error')): ?>
    <div class="container">
        <div class="alert alert-danger">
            <h4><?php echo e(trans('general.error')); ?></h4>
            <p> <?php echo Session::get('error'); ?> </p>
        </div>
    </div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="container">
        <div class="alert alert-success">
            <h4><?php echo e(trans('general.success')); ?></h4>
            <p> <?php echo e(Session::get('success')); ?> </p>
        </div>
    </div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="container">
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php endif; ?>