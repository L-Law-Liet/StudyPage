<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-4 left-block">
            <div class="form-group">
                <label for="degree">Степень</label>
                <select name="degree" class="form-control" id="degree">
                    <option value=""></option>
                    <option value=""></option>
                    <option value=""></option>
                </select>
            </div>
            <div class="form-group">
                <label for="course">Направление обучения</label>
                <select name="course" class="form-control" id="course">
                    <option value=""></option>
                    <option value=""></option>
                    <option value=""></option>
                </select>
            </div>
            <div class="form-group">
                <label for="place">Место обучения (регион)</label>
                <select name="place" class="form-control" id="place">
                    <option value=""></option>
                    <option value=""></option>
                    <option value=""></option>
                </select>
            </div>
            <div class="form-group">
                <label for="city">Город</label>
                <select name="city" class="form-control" id="city">
                    <option value=""></option>
                    <option value=""></option>
                    <option value=""></option>
                </select>
            </div>
            <div class="form-group">
                <label for="discipline">Предметы</label>
                <p>История</p>
                <p>Казахский</p>
                <p>Русский</p>
                <p>Математика</p>
                <input type="text" name="discipline" class="form-control" id="discipline" placeholder="Профильный предмет">
            </div>
            <div class="form-group">
                <label for="university">ВУЗ</label>
                <select name="university" class="form-control" id="university">
                    <option value=""></option>
                    <option value=""></option>
                    <option value=""></option>
                </select>
            </div>
            <div class="form-group">
                <label for="edu-type">Форма обучения</label>
                <select name="edu-type" class="form-control" id="edu-type">
                    <option value=""></option>
                    <option value=""></option>
                    <option value=""></option>
                </select>
            </div>
        </div>
        <div class="col-md-8 right-block">
            <div class="sgs-list-header clearfix">
                <div class="row">
                    <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
                        <p class="pull-left">Результат: результатов найдено <span class="count">0</span></p>
                    </div>
                    <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
                        <form class="form-horizontal sgs-list-sort" role="form">
                            <div class="form-group">
                                <label for="sortorder" class="sr-only">Сортировать по:</label>
                                <select class="form-control sgs-sort" id="sortorder" name="sort">
                                    <option value="name">Наименование</option>
                                    <option value="town">Город</option>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <ul class="sgs-list-ul">
                <?php for($i = 0; $i < 9; $i++): ?>
                <li>
                    <div>
                        <h3><a href="#"><strong>Вычислительная техника и программное обеспечение</strong> • <span>Национальный университет им. Л.Н.Гумилева</span> • Астана</a></h3>
                        <table>
                            <tbody>
                                <tr>
                                    <td>Степень</td>
                                    <td>Бакалавр</td>
                                </tr>
                                <tr>
                                    <td>Стоимостть обучение</td>
                                    <td>1 000 000 тг.</td>
                                </tr>
                                <tr>
                                    <td>Профильный предмет</td>
                                    <td>Физика</td>
                                </tr>
                                <tr>
                                    <td>Форма обучения</td>
                                    <td>Очная</td>
                                </tr>
                                <tr>
                                    <td>Рейтинг ВУЗа</td>
                                    <td>2</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </li>
                <?php endfor; ?>
            </ul>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>