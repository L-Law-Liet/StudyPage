<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?
        $url = $_SERVER['REQUEST_URI'];
        if ($url != '/') {
            $url = preg_replace("/\&search.+/", "", $url);
            $url = preg_replace("/\&page.+/", "", $url);
        }
    ?>
    <? $meta = \App\Models\Meta::where('page', '=', $url)->orWhere('page', '=', $url.'&page=1')->first(); ?>
    <? if (!empty($meta) AND isset($meta)) { ?>
        <title><?=$meta->title?></title>
        <meta name="description" content="<?=$meta->description?>">
        <meta name="keywords" content="<?=$meta->keywords?>">
    <? } else { ?>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
    <? } ?>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/slick.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" ></script>
    <?php echo $__env->yieldContent('js'); ?>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">

    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
			(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
				m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
			(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

			ym(57544288, "init", {
				clickmap:true,
				trackLinks:true,
				accurateTrackBounce:true
			});
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/57544288" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
    <!-- /Yandex.Metrika counter -->
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body oncontextmenu="return false" oncopy="return false;" oncontextmenu="return false" onselectstart="return false;">
<div id="app">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <!-- На главной странице множество js не работают из-за отсутствия токена -->
    <div id="header">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                    <div class="logos clearfix">
                        <h1>
                            <a href="/">
                                <img src="/img/logo.png">
                            </a>
                            <span class="sr-only"></span>
                        </h1>
                        <span class="sr-only">.</span>
                        
                            
                        <span class="sr-only">.</span>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                    <ul class="social-icons float-right">
                        <? use App\Models\Social; $social = Social::where('active', 1)->pluck('link', 'name')->all(); ?>
                        <? foreach ($social as $k => $soc) { ?>
                            <? if ($k == 'Instagram' OR $k == 'YouTube' OR $k == 'ВКонтакте' OR $k == 'Facebook' OR $k == 'Telegram') { ?>
                                <?php
                                    if ($k == 'Instagram') {
                                        $class = 'hin';
                                        $n = 'instagram';
                                        $id = '';
                                    } else if ($k == 'YouTube') {
                                        $class = 'hyo';
                                        $n = '';
                                        $id = 'yu';
                                    } else if ($k == 'ВКонтакте') {
                                        $class = 'hvk';
                                        $n = 'vk';
                                        $id = '';
                                    } else if ($k == 'Facebook') {
                                        $class = 'hfb';
                                        $n = '';
                                        $id = 'fb';
                                    } else if ($k == 'Telegram') {
                                        $class = 'hte';
                                        $n = 'telegram';
                                        $id = '';
                                    }
                                ?>
                                <? if ($n != '') { ?>
                                    <li><a target="_blank" id="<?=$id?>" class="<?=$class?>" href="<?=$soc?>"><i class="fab fa-<?=$n?>"></i></a></li>
                                <? } else { ?>
                                    <li><a target="_blank" href="<?=$soc?>" style="border:none;" id="<?=$id?>" class="<?=$class?>"></a></li>
                                <? } ?>
                            <? } ?>
                        <? } ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="header2">
        <div class="header2">
            <div class="container header-container">
                <div><i class="fas fa-users icon-header soc-icon-clicked"></i></div>
                <div><a href="/"><img src="/img/logo.png" class="logo"></a></div>
                <div><i class="fas fa-bars icon-header icon-menu-clicked"></i></div>
            </div>
        </div>
        <div class="slideList slideList-soc-icon">
            <ul>
                <? foreach ($social as $k => $soc) { ?>
                <? if ($k == 'Instagram' OR $k == 'YouTube' OR $k == 'ВКонтакте' OR $k == 'Facebook' OR $k == 'Telegram') { ?>
                    <?php
                    if ($k == 'Instagram') {
                        $n = 'instagram';
                    } else if ($k == 'YouTube') {
                        $n = 'youtube';
                    } else if ($k == 'ВКонтакте') {
                        $n = 'vk';
                    } else if ($k == 'Facebook') {
                        $n = 'facebook-f';
                    } else if ($k == 'Telegram') {
                        $n = 'telegram';
                    }
                    ?>
                        <li><a target="_blank" href="<?=$soc?>"><span class="soc-cyrcle"><i class="fab fa-<?=$n?>"></i></span> <?=$k?></a></li>
                    <? } ?>
                <? } ?>
            </ul>
        </div>
        <div class="slideList slideList-menu">
            <ul>
                <li><a class="bK dC<? if (!empty($_GET['degree_id']) AND $_GET['degree_id'] == 'bakalavriat') { ?> active<? } ?>" href="/poisk?degree_id=bakalavriat&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Бакалавриат</a></li>
                <li><a class="mG dC<? if (!empty($_GET['degree_id']) AND $_GET['degree_id'] == 'magistratura') { ?> active<? } ?>" href="/poisk?degree_id=magistratura&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Магистратура</a></li>
                <li><a class="dK dC<? if (!empty($_GET['degree_id']) AND $_GET['degree_id'] == 'doktorantura') { ?> active<? } ?>" href="/poisk?degree_id=doktorantura&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Докторантура</a></li>
                <li><a href="/list/">Список ВУЗов</a></li>
                <li><a href="/rating/">Рейтинг ВУЗов</a></li>
            </ul>
        </div>
    </div>
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel navbar-unipage">
        <div class="container">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link dC bK<? if (!empty($_GET['degree_id']) AND $_GET['degree_id'] == 'bakalavriat') { ?> active<? } ?>" href="/poisk?degree_id=bakalavriat&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Бакалавриат</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dC mG<? if (!empty($_GET['degree_id']) AND $_GET['degree_id'] == 'magistratura') { ?> active<? } ?>" href="/poisk?degree_id=magistratura&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Магистратура</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dC dK<? if (!empty($_GET['degree_id']) AND $_GET['degree_id'] == 'doktorantura') { ?> active<? } ?>" href="/poisk?degree_id=doktorantura&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Докторантура</a>
                    </li>
                    
                        
                    
                    <li class="nav-item">
                        <a class="nav-link <?php if(Request::path() == 'list'): ?> active <?php endif; ?>" href="/list/">Список вузов</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if(Request::path() == 'rating'): ?> active <?php endif; ?>" href="/rating/"><?php echo e(trans('general.rating_he')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="py-4">
        <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <div class="minimap">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <h2 class="sr-only">main navigation</h2>
                    <ul>
                        <li>
                            <span>Степень</span>
                            <ul>
                                <li class="">
                                    <a href="/poisk?degree_id=bakalavriat&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Бакалавриат</a>
                                </li>
                                <li>
                                    <a href="/poisk?degree_id=magistratura&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Магистратура</a>
                                </li>
                                <li>
                                    <a href="/poisk?degree_id=doktorantura&direction_id=any&subdirection_id=any&specialty_id=any&city_id=any&pr1=any&pr2=any&un_id=any&type_id=any&page=1">Докторантура</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <span>Поступление</span>
                            <ul>
                                
                                    
                                
                                
                                    
                                
                                <li>
                                    <a href="/navigator/">Навигатор</a>
                                </li>
                                <li>
                                    <a href="/list/">Список ВУЗов</a>
                                </li>
                                <li>
                                    <a href="/rating/">Рейтинг ВУЗов</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <span>Соглашение</span>
                            <ul>
                                <li>
                                    <a href="/article/5">ВУЗам</a>
                                </li>
                                <li>
                                    <a href="/article/4">Пользователям</a>
                                </li>
                                <li>
                                    <a href="/article/3">Рекламодателям</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <span>Контакты</span>
                            <ul>
                                <li>
                                    <a href="/article/2">О сайте</a>
                                </li>
                                <li>
                                    <a href="/article/1">Добавить ВУЗ</a>
                                </li>
                                <li>
                                    <a href="/callback">Обратная связь</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container">
            <? $year = Social::findOrFail(7); ?>
            <p class="text-center m-t-35">&copy; StudyPage <?=$year->link?> | Все права защищены</p>
            <!-- Yandex.Metrika counter -->
            <script type="text/javascript" >
                (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
                    m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
                (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

                ym(52723207, "init", {
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            </script>
            <noscript><div><img src="https://mc.yandex.ru/watch/52723207" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
            <!-- /Yandex.Metrika counter -->

        </div>
    </div>
    <div class="container">
        <a href="#app" id="bottom" class="sprites page-top" title="Back to top" style="display: block;">
            <span class="sr-only">Back to top</span>
        </a>
    </div>
</div>
</body>
</html>
