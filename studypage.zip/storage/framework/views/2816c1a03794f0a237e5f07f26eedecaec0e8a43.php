<?php $__env->startSection('content'); ?>
    <div class="content">
        <table class="table table-striped table-view">
            <tr>
                <th>Направление</th>
                <td><?php echo e($category->name); ?></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>