<?php $__env->startSection('title', 'Просмотр вопроса'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Просмотр вопроса</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <table class="table table-striped table-view">
                        <tr>
                            <th>Имя</th>
                            <td><?php echo e($callback->name); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo e($callback->email); ?></td>
                        </tr>
                        <tr>
                            <th>Вопрос</th>
                            <td><?php echo $callback->question; ?></td>
                        </tr>
                        <tr>
                            <th>Ответ</th>
                            <td><?php echo $callback->answer; ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>