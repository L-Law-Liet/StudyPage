<?php $__env->startSection('title', 'Просмотр ВУЗа'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Просмотр Пользователя</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <table class="table table-striped table-view">
                        <tr>
                            <th>Фамилия</th>
                            <td><?php echo e($user->surname??'Не указано'); ?></td>
                        </tr>
                        <tr>
                            <th>Имя</th>
                            <td><?php echo e($user->name??'Не указано'); ?></td>
                        </tr>
                        <tr>
                            <th>Дата рождения</th>
                            <td><?php echo e($user->birthDate??'Не указано'); ?></td>
                        </tr>
                        <tr>
                            <th>Пол</th>
                            <td><?php if($user->region): ?> <?php echo e(($user->gender == 'm')?'Мужской':'Женский'); ?> <?php else: ?> Не указано <?php endif; ?></td>
                        </tr>
                        
                        <tr>
                            <th>Регион</th>
                            <td><?php if($user->region): ?> <?php echo e(\App\Models\City::find($user->region)->name_ru); ?> <?php else: ?> Не указано <?php endif; ?></td>
                        </tr>
                        <tr>
                            <th>Электронная почта</th>
                            <td><?php echo e($user->email??'Не указано'); ?></td>
                        </tr>
                        <tr>
                            <th>Пароль</th>
                            <td><?php echo e($user->password??'Не указано'); ?></td>
                        </tr>
                        <tr>
                            <th>Баланс</th>
                            <td><?php echo e($user->bill??'Не указано'); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>