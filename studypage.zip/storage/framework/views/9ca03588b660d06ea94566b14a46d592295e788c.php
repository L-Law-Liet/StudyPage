<?php $__env->startSection('content'); ?>
    <div class="content">
        <a href="/admin/partner/add" class="btn btn-success pull-right">Добавить</a>
        <table class="table table-hover">
            <thead>
            <tr>
                <td>#</td>
                <td>Ссылка</td>
                <td>Изображение</td>
                <td width="5%" colspan="3" class="text-center">Действие</td>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($partner->firstItem()+$k); ?></td>
                    <td><?php echo e($v->link); ?></td>
                    <td>
                        <img src="/img/partners/<?php echo e($v->image); ?>" alt="<?php echo e($v->name); ?>" width="100px">
                    </td>
                    <td>
                        <a href="/admin/partner/view/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/partner/add/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/partner/delete/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                <td>Количество <?php echo e($count); ?></td>
                <td colspan = '2' class='text-center'><?php echo e($partner->links()); ?></td>
            </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>