<?php $__env->startSection('content'); ?>

    <div class="container pt-2">
        <div class="row">
            <div class="col-8">
                <div id="faq">
                    <h3 class="text-center"><?php echo e($faq->question); ?></h3>
                    <p class="faq-text text-justify">
                        <?php echo e($faq->answer); ?>

                    </p>
                </div>
            </div>
            <div class="col-md-4 pl-0">
                <ul class="faq-list">
                    <?php $__currentLoopData = \App\Models\Faq::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a <?php if($faq->id == $f->id): ?> class="color-C11800" <?php endif; ?> href="<?php echo e(url('faq', $f->id)); ?>"> <img <?php if($faq->id == $f->id): ?> src="<?php echo e(asset('img/arrow-dots-red.svg')); ?>" <?php else: ?> src="<?php echo e(asset('img/arrow-dots-black.svg')); ?>" <?php endif; ?> ><?php echo e($f->question); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>