<?php $__env->startSection('title', 'Редактировать ВУЗ'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php
        $title = is_null($id) ? 'Добавить' : 'Редактировать'
    ?>
    <h1><?php echo e($title); ?> ВУЗ</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/university/add':"/admin/university/add/$id";
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <form action="<?php echo e($action); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-md-3">Наименование ВУЗа </label>
                            <div class="col-md-9">
                                <input type="text" name="name_ru" class="form-control" <?php if(is_object($university)): ?> value="<?php echo e($university->name_ru); ?>" <?php endif; ?> >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Подразделение</label>
                            <div class="col-md-9">
                                <textarea name="subdivision" class="form-control"><?php if(is_object($university)): ?> <?php echo e($university->subdivision); ?> <?php endif; ?></textarea>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-md-3">Город</label>
                            <div class="col-md-9">
                                <select name="city_id" class="form-control city">
                                    <option></option>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($university) && $university->city_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Адресс</label>
                            <div class="col-md-9">
                                <input type="text" name="address_ru" class="form-control" <?php if(is_object($university)): ?> value="<?php echo e($university->address_ru); ?>" <?php endif; ?> >
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-md-3">Телефон</label>
                            <div class="col-md-9">
                                <input type="text" name="phone" class="form-control" <?php if(is_object($university)): ?> value="<?php echo e($university->phone); ?>" <?php endif; ?>>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Индекс</label>
                            <div class="col-md-9">
                                <input type="text" name="postcode" class="form-control" <?php if(is_object($university)): ?> value="<?php echo e($university->postcode); ?>" <?php endif; ?>>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">E-mail для обращения</label>
                            <div class="col-md-9">
                                <input type="text" name="email" class="form-control" <?php if(is_object($university)): ?> value="<?php echo e($university->email); ?>" <?php endif; ?>>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Веб-сайт</label>
                            <div class="col-md-9">
                                <input type="text" name="web_site" class="form-control" <?php if(is_object($university)): ?> value="<?php echo e($university->web_site); ?>" <?php endif; ?>>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Тип учебного заведения</label>
                            <div class="col-md-9">
                                <select name="type_id" class="form-control city">
                                    <option></option>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($university) && $university->type_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        
                            
                            
                                
                            
                        
                        <div class="clearfix">
                            <button class="btn btn-success pull-right">Сохранить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>