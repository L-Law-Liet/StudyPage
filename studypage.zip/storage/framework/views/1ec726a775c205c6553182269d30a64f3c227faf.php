<p>
    Здравствуйте!
</p>
<p>Вы запросили восстановление учетных записей на сайте <a href="www.studypage.net">studypage.net</a>.</p>
<ul>Ваши учетные записи:
    <?php if(!empty($email)): ?>
        <li>Email: <?php echo e($email); ?></li>
        <li>Пароль: <?php echo e($password); ?></li>
        <?php endif; ?>
</ul>
<p>
    Рекомендуем Вам сохранить это письмо.
</p>
<p>
    Желаем Вам успехов!
</p>
<p>
    <em>С уважением, команда Studypage.net</em>
</p>
