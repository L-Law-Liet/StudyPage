<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="cities">
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="city-content">
                    <a href="/city/view/<?php echo e($v->id); ?>"><h5><?php echo e($v->name_ru); ?></h5>
                    <img src="/img/cities/<?php echo e($v->image); ?>" alt="<?php echo e($v->name_ru); ?>" class="city-img"></a>
                    <div id="description">
                        <?php echo mb_substr($v->description, 0, 650, 'UTF-8'); ?>

                    </div>
                    <div class="clear"></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="city-pagination">
            <?php echo e($cities->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>