<?php $__env->startSection('content'); ?>
    <div class="main">
        <div class="container">
            <form method="POST" action="/poisk">
                <?php echo csrf_field(); ?>
                <div class="row main-row">
                    <div class="row main-row-inner">
                        <div class="bg-opacity"></div>
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="col-12">
                            <h3 class="text-center m-t-10">Выберите свою специальность</h3>
                            <div class="form-group m-b-0">
                                <input type="text" name="search" class="form-control" placeholder="Поиск">
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group m-b-0">
                                <label class="col-form-label"><i class="fas fa-graduation-cap"></i> Степень</label>
                                <select name="degree_id" class="form-control">
                                    <option value="">Выберите</option>
                                    <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group m-b-0">
                                <label class="col-form-label"><i class="fas fa-atlas"></i> Область обучения</label>
                                <select name="direction_id" class="form-control">
                                    <option value="">Выберите</option>
                                    <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <p class="text-right m-t-18">Доступно <?php echo e($cost_count); ?> специальностей</p>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="form-group">
                                <label class="col-form-label"><i class="fas fa-globe-americas"></i> Город</label>
                                <select name="city_id" class="form-control">
                                    <option value="">Выберите</option>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary-custom float-right">
                                    <?php echo e(trans('general.search')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <div class="row teaser-row">
                <div class="col-6">
                    <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($k === 3): ?>
                </div>
                <div class="col-6">
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-header" id="heading<?php echo e($k); ?>" data-toggle="collapse" data-target="#collapse<?php echo e($k); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($k); ?>">
                                <div class="mb-0">
                                    <?php echo e($v->question); ?> <i class="fas fa-angle-down float-right"></i>
                                </div>
                            </div>
                            <div id="collapse<?php echo e($k); ?>" class="collapse" aria-labelledby="heading<?php echo e($k); ?>">
                                <div class="card-body">
                                    <?php echo e($v->answer); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div id="city" class="carousel slide" data-ride="carousel">
                <h3>ВУЗы в городах Казахстана</h3>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="accordion">
                            <ul>
                                <?php $__currentLoopData = $cityslider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($k <> 0 && ($k%6) == 0): ?>
                            </ul>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="accordion">
                            <ul>
                                    <?php endif; ?>
                                    <li class="bg-<?php echo e($k); ?>">
                                        <div>
                                            <a href="/city/view/<?php echo e($v->id); ?>" class="sliderLink">
                                                <h2><?php echo e($v->name_ru); ?></h2>
                                            </a>
                                        </div>
                                    </li>
                                <style>
                                    .bg-<?php echo e($k); ?> {
                                        background-image: url("/img/cities/<?php echo e($v->image); ?>");
                                    }
                                </style>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#city" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#city" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>

            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>