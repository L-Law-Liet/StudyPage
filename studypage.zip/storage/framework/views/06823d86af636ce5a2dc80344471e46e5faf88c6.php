<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/partner/add':"/admin/partner/add/$id";
    ?>
    <div class="content">
        <h4>Добавить партнера</h4>
        <form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-3">Ссылка</label>
                <div class="col-9">
                    <input type="text" name="link" class="form-control" <?php if(is_object($partner)): ?> value="<?php echo e($partner->link); ?>" <?php endif; ?>>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-3">Изображение</label>
                <div class="col-9">
                    <input type="file" name="image">
                </div>
            </div>
            <div class="clearfix">
                <button class="btn btn-success pull-right">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>