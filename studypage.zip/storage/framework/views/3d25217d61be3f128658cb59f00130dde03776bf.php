<?php $__env->startSection('content'); ?>
    <div class="content">
        <table class="table table-striped table-view">
            <tr>
                <th>Дата создания</th>
                <td><?php echo e(\Carbon\Carbon::parse($language->created_at)->format('d.m.Y')); ?></td>
            </tr>
            <tr>
                <th>Наименование</th>
                <td><?php echo e($language->name_ru); ?></td>
            </tr>
            
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>