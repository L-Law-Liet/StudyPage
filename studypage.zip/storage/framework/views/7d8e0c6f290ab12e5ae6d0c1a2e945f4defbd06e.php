

<?php $__env->startSection('title', 'Специальность в ВУЗе'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Специальность в ВУЗе</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <form action="/admin/cost/" method="GET">
                        <div class="form-group row">
                            <label class="col-md-2">Университет</label>
                            <div class="col-md-2">
                                <select name="university_id" class="form-control">
                                    <option></option>
                                    <?php $__currentLoopData = $university; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <label class="col-md-2">Степень</label>
                            <div class="col-md-2">
                                <select name="degree_id" class="form-control">
                                    <option></option>
                                    <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <input type="text" name="cipher" class="form-control" placeholder="Шифр">
                            </div>
                            <div class="col-md-2">
                                <a href="/admin/cost/" class="btn btn-warning pull-right">Сбросить</a>
                                <button type="submit" class="btn btn-primary pull-right mr-15">Фильтр</button>
                            </div>
                        </div>
                    </form>
                    <a href="/admin/cost/add" class="btn btn-success pull-right">Добавить</a>
                </div>
                <div class="box-body">
                    <table class="table table-hover">
                        <thead>
                             <tr>
                                <th width="2%">#</th>
                                <th>Университет</th>
                                <th>Специальность</th>
                                <th>Цена</th>
                                <th colspan="3" class="text-center">Действие</th>
                             </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $cost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($cost->firstItem()+$k); ?></td>
                                <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e($v->relUniversity->name_ru); ?></a></td>
                                <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e($v->relSpecialty->cipher); ?> - <?php echo e($v->relSpecialty->name_ru); ?></a></td>
                                <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e(number_format($v->price, 0, '', ' ')); ?></a></td>
                                <td>
                                    <a href="/admin/cost/view/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                                    </a>
                                </td>
                                <td>
                                    <a href="/admin/cost/add/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                                    </a>
                                </td>
                                <td>
                                    <a href="/admin/cost/delete/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan = '3'>Количество <?php echo e($count); ?></td>
                                <td colspan = '4' class='text-center'><?php echo e($cost->links()); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>