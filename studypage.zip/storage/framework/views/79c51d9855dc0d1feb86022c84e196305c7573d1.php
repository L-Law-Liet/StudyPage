<?php $__env->startSection('content'); ?>
    <div class="content">
        <a href="/admin/rating/add" class="btn btn-success pull-right">Добавить</a>
        <table class="table table-hover">
            <thead>
                 <tr>
                    <th width="2%">№</th>
                    <th>Университет</th>
                    <th>Направление</th>
                    <th>Город</th>
                    <th>Итого (Балл)</th>
                    <th colspan="3" class="text-center">Действие</th>
                 </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rating->firstItem()+$k); ?></td>
                    <td><?php echo e($v->relUniversity->name_ru); ?></td>
                    <td><?php if(is_object($v->relCategory)): ?><?php echo e($v->relCategory->name); ?><?php endif; ?></td>
                    <td><?php echo e($v->relCity->name_ru); ?></td>
                    <td><?php echo e($v->overall_rating); ?></td>
                    <td>
                        <a href="/admin/rating/view/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/rating/add/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/rating/delete/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td>Количество <?php echo e($count); ?></td>
                    <td colspan = '2' class='text-center'><?php echo e($rating->links()); ?></td>
                </tr>
            </tfoot>
        </table>
        <?php
            $action = (!is_object($ranking) && empty($ranking->source))?'/admin/rating/source':"/admin/rating/source/$ranking->id";
        ?>
        <form action="<?php echo e($action); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-md-3">Источник</label>
                <div class="col-md-9">
                    <input type="text" name="source" class="form-control" <?php if(is_object($ranking)): ?> value="<?php echo e($ranking->source); ?>" <?php endif; ?>>
                </div>
            </div>
            <div class="clearfix">
                <button class="btn btn-success pull-right"><?php if(is_object($ranking) && !empty($ranking->source)): ?> Изменить <?php else: ?> Сохранить <?php endif; ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>