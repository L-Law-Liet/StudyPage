<?php $__env->startSection('content'); ?>
    <div class="content">
        <table class="table table-striped table-view">
            <tr>
                <th>Дата создания</th>
                <td><?php echo e(\Carbon\Carbon::parse($university->created_at)->format('d.m.Y')); ?></td>
            </tr>
            <tr>
                <th>Наименование ВУЗа</th>
                <td><?php echo e($university->name_ru); ?></td>
            </tr>
            <tr>
                <th>Подразделение</th>
                <td><?php echo $university->subdivision; ?></td>
            </tr>
            
            <tr>
                <th>Город</th>
                <td><?php echo e($city->name_ru); ?></td>
            </tr>
            <tr>
                <th>Адрес</th>
                <td><?php echo e($university->address_ru); ?></td>
            </tr>
            
            <tr>
                <th>Телефон</th>
                <td><?php echo e($university->phone); ?></td>
            </tr>
            <tr>
                <th>Индекс</th>
                <td><?php echo e($university->postcode); ?></td>
            </tr>
            <tr>
                <th>Краткая информация</th>
                <td><?php echo e($university->information_ru); ?></td>
            </tr>
            <tr>
                <th>Тип учебного заведения</th>
                <td><?php echo e(!is_null($university->relType) ? $university->relType->name_ru : ''); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo e($university->email); ?></td>
            </tr>
            <tr>
                <th>Website</th>
                <td><?php echo e($university->web_site); ?></td></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>