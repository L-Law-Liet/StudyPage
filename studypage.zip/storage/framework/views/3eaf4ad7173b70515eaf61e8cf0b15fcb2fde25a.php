<?php $__env->startSection('css'); ?>
    <style>
        body {
            font-family: Futura PT, sans-serif;
        }
        main.mt-5 {
            margin-top: 0 !important;
        }
        main.py-4 {
            padding-top: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div id="college-view-right">
            <div>
                <h3 class="text-center">По результатам теста Ваш балл составляет: <b><?php echo e($score); ?></b></h3>
            </div>
            <div>
                <table id="ent-table">
                    <thead>
                    <tr>
                        <td colspan="4" class="ent-td w-75 p-2" ><?php echo e($title); ?></td>
                    </tr>
                    </thead>
                    <tbody class="ent-tbody">
                    <tr hidden>
                        <td>“Равно” или “больше” проходного балла на грант</td>
                        <td>“Меньше с 1 по 5 баллов” чем проходной балл на грант (5)</td>
                        <td>“Меньше с 6 по 13 баллов” чем проходной балл на грант (10)</td>
                        <td>“Меньше с 14 баллов” чем проходной балл на грант, но не меньше проходного балла на платное</td>
                    </tr>
                    <?php
                        $pageSize = $page*5+5;
                        if ($pageSize >  count($array)/4)
                            $pageSize = count($array)/4;
                    ?>
                    <?php for($i = $page*5; $i < $pageSize; $i++): ?>
                        <tr>
                            <?php
                            $row = ($i+1)*4;
                            if ($row > ceil(count($array)))
                                $row = ceil(count($array));
                            ?>
                            <?php for($j = $i*4; $j < $row; $j++): ?>
                                    <td>
                                        <div class="justify-content-start d-flex">
                                            <div class="w-8"><i class="fas fa-graduation-cap"></i></div>
                                            <b>
                                                <a class="ent-href" href="<?php echo e(route('resToSearch', [$array[$j]->subdirection_id, $array[$j]->getCost()->university_id, $profs1, $profs2])); ?>"><?php echo e($array[$j]->relSubdirection->name_ru); ?></a>
                                            </b>
                                        </div>
                                        <div class="d-flex justify-content-start">
                                            <div class="w-8"><i class="fas fa-building"></i></div>
                                            <p class="mb-0">
                                                <a class="ent-href" href="<?php echo e(route('resToSearch', [$array[$j]->subdirection_id, $array[$j]->getCost()->university_id, $profs1, $profs2])); ?>"><?php echo e($array[$j]->getCost()->relUniversity->name_ru); ?></a>
                                            </p>
                                        </div>
                                        <div class="d-flex justify-content-start">
                                            <div class="w-8"></div>
                                            <div><b>Проходной балл: <?php echo e($array[$j]->getCost()->passing_score); ?></b></div>
                                        </div>
                                    </td>
                                <?php endfor; ?>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>

                <div class="pagination-block m-2 p-2">
                    <div class="row m-1">
                        <button id="prevPage" <?php if($page > 0): ?> onclick="window.location='<?php echo e(route('result-ent2', [$type, encrypt($score), $profs1, $profs2, ($page-1)])); ?>'" style="cursor: pointer" <?php else: ?> disabled <?php endif; ?> class="col-1 d-flex text-center"><img <?php if($page > 0): ?> class="Img" <?php endif; ?> src="<?php echo e(asset('img/pagination-left.svg')); ?>" alt=""></button>
                        <div class="col-10 text-center form-group position-relative">
                            <div id="select-div2">
                                <select id="pagination-select2" class="custom-control-inline border-0 m-0 ml-5" style="outline: 0" onchange="javascript:location.href = this.value;">
                                    <?php for($i = 0; $i < ceil(count($array)/20); $i++): ?>
                                        <?php if($i == $page): ?>
                                            <option value="" hidden selected><?php echo e((1+$page)); ?> из <?php echo e(ceil(count($array)/20)); ?></option>
                                            <option class="font-weight-bold" value="" disabled>Страница <?php echo e($i+1); ?></option>
                                        <?php else: ?>
                                            <option class="nPage" value="<?php echo e(route('result-ent2', [$type, encrypt($score), $profs1, $profs2, $i])); ?>">Страница <?php echo e($i+1); ?></option>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </select>
                                
                            </div>
                        </div>
                        <button id="nextPage" <?php if($page < ceil(count($array)/20)-1): ?> onclick="window.location='<?php echo e(route('result-ent2', [$type, encrypt($score), $profs1, $profs2, ($page+1)])); ?>'" style="cursor: pointer" <?php else: ?> disabled <?php endif; ?> class="col-1 d-flex text-center"><img <?php if($page < ceil(count($array)/20)-1): ?> class="Img" <?php endif; ?> src="<?php echo e(asset('img/pagination-right.svg')); ?>" alt=""></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.ent-href').mouseover(function () {
                console.log($(this).parent().parent().parent());
                $(this).parent().parent().parent().find('.ent-href').css({
                    "color": "#c11800",
                });
            });
            $('.ent-href').mouseout(function () {
                $(this).parent().parent().parent().find('.ent-href').css({
                    "color": "black",
                });
            });
            $('.pagination-block button').mouseover(function () {
                if(this.id == 'nextPage'){
                    $('img', this).attr('src', "<?php echo e(asset('img/pagination-right-red.svg')); ?>");
                }
                else {
                    $('img', this).attr('src', "<?php echo e(asset('img/pagination-left-red.svg')); ?>");
                }
            });
            $('.pagination-block button').mouseout(function () {
                if(this.id == 'nextPage'){
                    $('img', this).attr('src', "<?php echo e(asset('img/pagination-right.svg')); ?>");
                }
                else {
                    $('img', this).attr('src', "<?php echo e(asset('img/pagination-left.svg')); ?>");
                }
            });
        });
        jQuery(function () {
            jQuery("#pagination-select2").change(function () {
                location.href = jQuery(this).val();
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>