<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h3 class="text-center m-b-10 font-weight-bold">ОБРАТНАЯ СВЯЗЬ</h3>
                <form action=<?php echo e(URL::action("IndexController@postCallback")); ?> method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-md-3">Имя</label>
                        <div class="col-md-9">
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3">Электронная почта</label>
                        <div class="col-md-9">
                            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3">Вопрос</label>
                        <div class="col-md-9">
                            <textarea name="question" class="form-control"><?php echo e(old('question')); ?></textarea>
                        </div>
                    </div>
                    <div class="clearfix">
                        <button class="btn btn-success float-right">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>