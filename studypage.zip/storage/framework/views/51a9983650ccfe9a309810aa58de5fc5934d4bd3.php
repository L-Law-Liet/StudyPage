<?php $__env->startSection('content'); ?>
    <div class="content">
        <form action="/admin/cost/" method="GET">
            <div class="form-group row">
                <label class="col-md-3">Университет</label>
                <div class="col-md-6">
                    <select name="university_id" class="form-control">
                        <option></option>
                        <?php $__currentLoopData = $university; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <a href="/admin/cost/" class="btn btn-warning pull-right">Сбросить фильтр</a>
                    <button type="submit" class="btn btn-primary pull-right mr-15">Фильтр</button>
                </div>
            </div>
        </form>
        <a href="/admin/cost/add" class="btn btn-success pull-right">Добавить</a>
        <table class="table table-hover">
            <thead>
                 <tr>
                    <th width="2%">#</th>
                    <th>Университет</th>
                    <th>Специальность</th>
                    <th>Цена</th>
                    <th colspan="3" class="text-center">Действие</th>
                 </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $cost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cost->firstItem()+$k); ?></td>
                    <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e($v->relUniversity->name_ru); ?></a></td>
                    <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e($v->relSpecialty->name_ru); ?></a></td>
                    <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e(number_format($v->price, 0, '', ' ')); ?></a></td>
                    <td>
                        <a href="/admin/cost/view/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/cost/add/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/cost/delete/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td>Количество <?php echo e($count); ?></td>
                    <td colspan = '2' class='text-center'><?php echo e($cost->links()); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>