<?php $__env->startSection('content'); ?>
    <div class="content">
        <a href="/admin/rating/add" class="btn btn-success pull-right">Добавить</a>
        <table class="table table-hover">
            <thead>
                 <tr>
                    <th width="2%">№</th>
                    <th>Университет</th>
                    <th>Город</th>
                    <th>Общая оценка</th>
                    <th>Статистический анализ</th>
                    <th>Индекс лояльности</th>
                    <th>Интернет-ресурс</th>
                    <th colspan="3" class="text-center">Действие</th>
                 </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rating->firstItem()+$k); ?></td>
                    <td><?php echo e($v->relUniversity->name_ru); ?></td>
                    <td><?php echo e($v->relCity->name_ru); ?></td>
                    <td><?php echo e($v->overall_rating); ?></td>
                    <td><?php echo e($v->statistic_analysis); ?></td>
                    <td><?php echo e($v->loyalty_index); ?></td>
                    <td><?php echo e($v->online_resource); ?></td>
                    <td>
                        <a href="/admin/rating/view/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/rating/add/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/rating/delete/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td>Количество <?php echo e($count); ?></td>
                    <td colspan = '2' class='text-center'><?php echo e($rating->links()); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>