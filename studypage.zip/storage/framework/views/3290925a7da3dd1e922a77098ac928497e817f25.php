<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4 left-block">
                <div class="form-group">
                    <label for="degree">Степень</label>
                    <select name="degree_id" class="form-control degree" id="degree_id">
                        <option value=""></option>
                        <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(!is_null($degree_id) && $degree_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="direction_id">Направление обучения</label>
                    <select name="direction_id" class="form-control direction" id="direction_id">
                        <option value=""></option>
                        <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(!is_null($direction_id) && $direction_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="state_id">Место обучения (регион)</label>
                    <select name="state_id" class="form-control state" id="state_id">
                        <option></option>
                        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(!is_null($state_id) && $state_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="city_id">Город</label>
                    <select name="city_id" class="form-control city" id="city_id">
                        <option value=""></option>
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="discipline">Предметы</label>
                    <p>История</p>
                    <p>Казахский</p>
                    <p>Русский</p>
                    <p>Математика</p>
                    <select name="subject_id" class="form-control subject" id="subject_id">
                        <option value="">Профильный предмет</option>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>ВУЗ</label>
                    <select name="university_id" class="form-control university" id="university_id">
                        <option value=""></option>
                        <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Форма обучения</label>
                    <select name="form_education_id" class="form-control form_education" id="form_education_id">
                        <option value=""></option>
                        <?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="col-md-8 right-block">
                <div class="sgs-list-header clearfix">
                    <div class="row">
                        <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
                            <p class="pull-left">Результат: результатов найдено <span class="count">0</span></p>
                        </div>
                        <div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
                            <form class="form-horizontal sgs-list-sort" role="form">
                                <div class="form-group">
                                    <label for="sortorder" class="sr-only">Сортировать по:</label>
                                    <select class="form-control sgs-sort" id="sortorder" name="sort">
                                        <option value="name">Наименование</option>
                                        <option value="town">Город</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="result">
                    <ul class="sgs-list-ul">
                        <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div>
                                    <h3><a href="#"><strong><?php echo e($v->relSpecialty->name_ru); ?></strong> • <span><?php echo e($v->relUniversity->name_ru); ?></span> • <?php echo e($v->relUniversity->relCity->name_ru); ?></a></h3>
                                    <table>
                                        <tbody>
                                        <tr>
                                            <td>Степень</td>
                                            <td><?php echo e($v->relSpecialty->relDegree->name_ru); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Стоимостть обучение</td>
                                            <td><?php echo e($v->price); ?> тг.</td>
                                        </tr>
                                        <tr>
                                            <td>Профильный предмет</td>
                                            <td><?php echo e($v->relSpecialty->relSubject->name_ru); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Форма обучения</td>
                                            <td><?php echo e($v->relSpecialty->relForm->name_ru); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Рейтинг ВУЗа</td>
                                            <td><?php echo e($v->relUniversity->kz_rating); ?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php echo e($specialties->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>