<?php $__env->startSection('content'); ?>
    <div class="content">
        <a href="/admin/cost/add" class="btn btn-success pull-right">Добавить</a>
        <table class="table table-hover">
            <thead>
                 <tr>
                    <th width="2%">#</th>
                    <th>Университет</th>
                    <th>Специальность</th>
                    <th>Цена</th>
                    <th colspan="3" class="text-center">Действие</th>
                 </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $cost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cost->firstItem()+$k); ?></td>
                    <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e(\App\Models\University::find($v->university_id)->name_ru); ?></a></td>
                    <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e(App\Models\Specialty::find($v->specialty_id)->name_ru); ?></a></td>
                    <td><a href="/admin/cost/view/<?php echo e($v->id); ?>"><?php echo e(number_format($v->price, 0, '', ' ')); ?></a></td>
                    <td>
                        <a href="/admin/cost/view/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/cost/add/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/cost/delete/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td>Количество <?php echo e($count); ?></td>
                    <td colspan = '2' class='text-center'><?php echo e($cost->links()); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>