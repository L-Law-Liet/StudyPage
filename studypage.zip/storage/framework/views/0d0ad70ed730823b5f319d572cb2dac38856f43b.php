<?php $__env->startSection('title', 'Редактировать требование'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php
        $title = is_null($id) ? 'Добавить' : 'Редактировать'
    ?>
    <h1><?php echo e($title); ?> требование</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/requirement/add':"/admin/requirement/add/$id";
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <form action="<?php echo e($action); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-md-3">Степень</label>
                            <div class="col-md-9">
                                <select name="degree_id" class="form-control">
                                    <option></option>
                                    <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($requirement) && $requirement->degree_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-md-3">Текст</label>
                            <div class="col-md-9">
                                <textarea name="content_ru" class="form-control"><?php if(is_object($requirement)): ?> <?php echo e($requirement->content_ru); ?> <?php endif; ?></textarea>
                            </div>
                        </div>
                        
                        <div class="clearfix">
                            <button class="btn btn-success pull-right">Сохранить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>