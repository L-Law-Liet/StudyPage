<?php $__env->startSection('title', 'Административная панель'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->startSection('content'); ?>
    <p>
        Добро пожаловать в админ панель!
    </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('datepicker/js/bootstrap-datepicker.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('datepicker/locales/bootstrap-datepicker.ru.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/admin.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>