<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" ></script>
<?php echo $__env->yieldContent('js'); ?>

<!-- Fonts -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
<div id="app">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <!-- На главной странице множество js не работают из-за отсутствия токена -->
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/admin')); ?>"><i class="fas fa-cog"></i> Административная панель - Unipage</a>
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>" target="_blank"><i class="fas fa-eye"></i> Просмотр сайта</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <?php if(auth()->guard()->guest()): ?>
                        <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
                        <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></li>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <main class="py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-3 vertical-menu">
                    <div class="nav-side-menu">
                        <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
                        <div class="menu-list">
                            <ul id="menu-content" class="menu-content collapse out">
                                <a href="/admin/university">
                                    <li><i class="fa fa-university fa-lg"></i> ВУЗы</li>
                                </a>
                                
                                <a href="/admin/direction">
                                    <li><i class="fa fa-user-graduate fa-lg"></i> Направление обучения</li>
                                </a>
                                <a href="/admin/subject">
                                    <li><i class="fa fa-graduation-cap fa-lg"></i> Предметы</li>
                                </a>
                                <a href="/admin/form">
                                    <li><i class="fab fa-wpforms fa-lg"></i> Форма обучения</li>
                                </a>
                                <a href="/admin/specialty">
                                    <li><i class="fa fa-user-tie fa-lg"></i> Специальности</li>
                                </a>
                                <a href="/admin/rating">
                                    <li><i class="fa fa-globe-asia fa-lg"></i> Рейтинг ВУЗов</li>
                                </a>
                                <a href="/admin/language">
                                    <li><i class="fa fa-language fa-lg"></i> Языки обучения</li>
                                </a>
                                <a href="/admin/cost">
                                    <li><i class="fa fa-dollar-sign fa-lg"></i> Специальность в ВУЗе</li>
                                </a>
                                <a href="/admin/faqs">
                                    <li><i class="fa fa-comments fa-lg"></i> FAQs</li>
                                </a>
                                <a href="/admin/requirement">
                                    <li><i class="far fa-file-alt fa-lg"></i> Требования к поступлению</li>
                                </a>
                                <a href="/admin/user">
                                    <li><i class="fa fa-users fa-lg"></i> Пользователи</li>
                                </a>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-9">
                    <?php if(Session::has('flash_message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('flash_message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger">
                            <h4><?php echo e(trans('general.error')); ?></h4>
                            <p> <?php echo Session::get('error'); ?> </p>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <h4><?php echo e(trans('general.success')); ?></h4>
                            <p> <?php echo e(Session::get('success')); ?> </p>
                        </div>
                    <?php endif; ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </main>
</div>
</body>
</html>
