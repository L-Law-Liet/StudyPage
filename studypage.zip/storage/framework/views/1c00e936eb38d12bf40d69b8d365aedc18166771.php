

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-view">
                    <thead>
                        <tr>
                            <th>№</th>
                            <th class="text-center">Наименование ВУЗа</th>
                            <th>Город</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                    <?php $category_id = null; ?>
                    <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $category_id = $v->category_id; ?>
                        <tr>
                            <td><?php echo e($k+1); ?></td>
                            <td><?php echo e($v->relUniversity->name_ru); ?></td>
                            <td><?php echo e($v->relCity->name_ru); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <?php if(is_object($ranking) && !empty($ranking->source)): ?>
                        <tfoot>
                            <tr>
                                <td colspan = '3'><b>Источник:</b> <?php echo e($ranking->source); ?></td>
                            </tr>
                        </tfoot>
                    <?php endif; ?>
                </table>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>