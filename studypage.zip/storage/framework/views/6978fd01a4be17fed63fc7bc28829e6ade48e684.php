<?php $__env->startSection('css'); ?>
    <style>
        main.mt-5 {
            margin-top: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="studiengangsuche sgs-detail" id="studiengangsuche">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <p class="back-link">
                        <a href="<?php echo e(url()->previous()); ?>"><span><img class="mr-2" src="<?php echo e(asset('img/arrow-left.svg')); ?>" alt=""></span>Вернуться к результатам поиска</a>
                    </p>
                    <div class="sgs-adress-header">
                        <h2>
                            <div>
                               <span class="sgs-rod"> <?php echo e($s->name_ru); ?> </span>
                            </div>
                            <div>
                                <span class="sgs-rod"> <?php echo e($u->name_ru); ?> </span>
                                <span class="sgs-rod">• <?php echo e($u->relCity->name_ru); ?> </span>
                            </div>
                        </h2>
                    </div>
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation"><a class="active" data-toggle="tab" href="#overview" role="tab" id="ui-tab-1" tabindex="0" aria-selected="true" aria-controls="overview">Обзор</a>
                        </li>
                        <li role="presentation" class=""><a data-toggle="tab" href="#doc" role="tab" id="ui-tab-2" tabindex="-1" aria-selected="false" aria-controls="doc">Документ</a>
                        </li>
                        <li onclick="window.location='<?php echo e(url('college/view', [$u->id, $href])); ?>'" role="presentation" class="clickable-el"><a data-toggle="tab" role="tab" id="ui-tab-3" tabindex="-1" aria-selected="false" aria-controls="pageCollege">Страница <?php echo e(($href == 'univer')?'ВУЗа':'КОЛЛЕДЖА'); ?></a>
                        </li>
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                    <div class="tab-content">
                        <div id="overview" class="tab-pane fade active in" role="tabpanel" tabindex="0" aria-hidden="false" aria-labelledby="ui-tab-1">
                            <h3>Язык обучения</h3>
                            <p> <?php echo e(\App\Models\Language::where('id', \App\Models\CostEducation::where('specialty_id', $s->id)->where('university_id', $u->id)->first()->language_id)->first()->name_ru); ?> </p>
                            <h3>Срок обучения</h3>
                            <p> <?php echo e($s->education_time); ?> </p>
                            <h3><?php echo e($f[0]); ?></h3>
                            <p> <?php echo e($requirement->relDegree->name_ru); ?> </p>
                            <h3>Стоимость обучения</h3>
                            <p> <?php echo e(\App\Models\CostEducation::where('specialty_id', $s->id)->where('university_id', $u->id)->first()->price); ?> тенге / год</p>
                            <h3><?php echo e($f[1]); ?></h3>
                            <p> <?php echo e($f[2]); ?> </p>
                            <?php if($f[3] ?? ''): ?>
                                <h3><?php echo e($f[3]); ?></h3>
                                <p> <?php echo e($f[4]); ?> </p>
                                <?php endif; ?>
                            <h3>Форма обучения</h3>
                            <p> <?php echo e($s->getCost()->education_form); ?> </p>
                        </div>
                        <div id="doc" class="tab-pane fade" role="tabpanel" tabindex="-1" aria-hidden="true" aria-labelledby="ui-tab-2">
                            <?php if(is_object($requirement)): ?> <?php echo $requirement->content_ru; ?> <?php endif; ?>
                        </div>
                        <div id="rating" class="tab-pane fade" role="tabpanel" tabindex="-1" aria-hidden="true" aria-labelledby="ui-tab-3">
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                    <div class="sgs-adress">
                        <h3>Контакты</h3>
                        <p><b> <?php echo e($u->name_ru); ?> </b></p>
                        <?=$u->subdivision?>
                        <p> <?php echo e($u->address_ru); ?> </p>
                        <p> <?php echo e($u->postcode); ?> <?php echo e($u->relCity->name_ru); ?> </p>
                        <p>Тел: <?php echo e($u->phone); ?> </p>
                        <p> <?php echo e($u->email); ?> </p>
                        <p> Сайт: <?php echo e(ltrim($u->web_site, 'Website: ')); ?> </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>