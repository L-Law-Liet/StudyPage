<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="text-center"><strong><?php echo e($article->title); ?></strong></h3>
        <div id="description" class="text-justify">
            <?php echo $article->description; ?>

        </div>
        <?php if(Request::path() == 'article/1'): ?>
            <?php echo $__env->make('proposal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>