<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table table-striped table-view">
            <thead>
                <tr>
                    <th>№</th>
                    <th>Университет</th>
                    <th>Город</th>
                    <th>Общая оценка</th>
                    <th>Статический анализ</th>
                    <th>Индекс лоялности</th>
                    <th>Интернет-ресурс</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($k+1); ?></td>
                    <td><?php echo e($v->relUniversity->name_ru); ?></td>
                    <td><?php echo e($v->relCity->name_ru); ?></td>
                    <td><?php echo e($v->overall_rating); ?></td>
                    <td><?php echo e($v->statistic_analysis); ?></td>
                    <td><?php echo e($v->loyalty_index); ?></td>
                    <td><?php echo e($v->online_resource); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan = '3'>Количество <?php echo e($count); ?></td>
                    <td colspan = '4' class='text-center'><?php echo e($rating->links()); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>