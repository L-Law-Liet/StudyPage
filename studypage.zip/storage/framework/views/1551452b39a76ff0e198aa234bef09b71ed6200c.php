<?php $__env->startSection('content'); ?>
    <div class="content">
        <table class="table table-striped table-view">
            <tr>
                <th>Ссылка</th>
                <td><?php echo e($partner->link); ?></td>
            </tr>
            <tr>
                <th>Ответ</th>
                <td><img src="/img/partners/<?php echo e($partner->image); ?>" alt="<?php echo e($partner->image); ?>" width="200px"></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>