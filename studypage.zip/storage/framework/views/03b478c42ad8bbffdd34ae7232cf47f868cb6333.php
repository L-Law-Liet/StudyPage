<?php $__env->startSection('css'); ?>
    <style>
        main.mt-5 {
            margin-top: 0 !important;
        }
        main.py-4 {
            padding-top: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container pt-2">
        <div class="row">
            <div class="col-8">
                <div id="college-view-right">
                    <h4 class="text-center mb-4">КОНТАКТЫ</h4>
                    <div>
                        <div class="cv-text font-weight-bold text-center mt-3">
                                <p>Адресс: <?php echo e($university->address_ru); ?></p>
                                <p><?php echo e($university->email); ?></p>
                                <p>Телефон: <?php echo e($university->phone); ?></p>
                                <p><?php echo e($university->web_site); ?></p>
                                <p>Почтовый код: <?php echo e($university->postcode); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('college/college-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>