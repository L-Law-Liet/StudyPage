<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/cost/add':"/admin/cost/add/$id";
    ?>
    <div class="content">
        <h4>Добавить специальность в ВУЗ</h4>
        <form action="<?php echo e($action); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-md-3">Университет</label>
                <div class="col-md-9">
                    <select name="university_id" class="form-control">
                        <option></option>
                        <?php $__currentLoopData = $university; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(is_object($cost) && $cost->university_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Специальность</label>
                <div class="col-md-9">
                    <select name="specialty_id" class="form-control">
                        <option></option>
                        <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(is_object($cost) && $cost->specialty_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Язык обучения</label>
                <div class="col-md-9">
                    <select name="language_id" class="form-control">
                        <option></option>
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(is_object($cost) && $cost->language_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label class="col-md-8">Стоимость обучения</label>
                    <div class="col-md-4">
                        <input type="text" name="price" class="form-control" <?php if(is_object($cost)): ?> value="<?php echo e($cost->price); ?>" <?php endif; ?>>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="col-md-8">Год</label>
                    <div class="col-md-4">
                        <input type="number" name="year" class="form-control" <?php if(is_object($cost)): ?> value="<?php echo e($cost->year); ?>" <?php endif; ?>>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label class="col-md-8">Рейтинг специальности</label>
                    <div class="col-md-4">
                        <input type="text" name="rating" class="form-control" <?php if(is_object($cost)): ?> value="<?php echo e($cost->rating); ?>" <?php endif; ?>>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="col-md-8">Итого</label>
                    <div class="col-md-4">
                        <input type="text" name="total" class="form-control" <?php if(is_object($cost)): ?> value="<?php echo e($cost->total); ?>" <?php endif; ?>>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label class="col-md-8">Количество грантов на русское отделение</label>
                    <div class="col-md-4">
                        <input class="form-control" type="text" name="number_grants_ru" <?php if(is_object($cost)): ?> value="<?php echo e($cost->number_grants_ru); ?>" <?php endif; ?>>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="col-md-8">Количество грантов на казахское отделение</label>
                    <div class="col-md-4">
                        <input class="form-control" type="text" name="number_grants_kz" <?php if(is_object($cost)): ?> value="<?php echo e($cost->number_grants_kz); ?>" <?php endif; ?>>
                    </div>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-6">
                    <label class="col-md-8">Проходной балл на русское отделение</label>
                    <div class="col-md-4">
                        <input class="form-control" type="text" name="passing_score_ru" <?php if(is_object($cost)): ?> value="<?php echo e($cost->passing_score_ru); ?>" <?php endif; ?>>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="col-md-8">Проходной балл на казахское отделение</label>
                    <div class="col-md-4">
                        <input class="col-md-4 form-control" type="text" name="passing_score_kz" <?php if(is_object($cost)): ?> value="<?php echo e($cost->passing_score_kz); ?>" <?php endif; ?>>
                    </div>
                </div>
            </div>
            <div class="clearfix">
                <button class="btn btn-success pull-right">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>