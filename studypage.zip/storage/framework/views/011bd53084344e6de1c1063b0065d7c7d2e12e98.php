

<?php $__env->startSection('title', 'Просмотр рейтинга ВУЗов'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Просмотр рейтинга ВУЗов</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <table class="table table-striped table-view">
                        <tr>
                            <th>Университет</th>
                            <td><?php echo e($rating->relUniversity->name_ru); ?></td>
                        </tr>
                        <tr>
                            <th>Город</th>
                            <td><?php echo e($rating->relCity->name_ru); ?></td>
                        </tr>
                        <tr>
                            <th>Итого (Балл)</th>
                            <td><?php echo e($rating->overall_rating); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>