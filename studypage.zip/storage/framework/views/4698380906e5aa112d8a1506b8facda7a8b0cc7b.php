<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4 left-block">
                <div class="form-group">
                    <label for="degree">Степень обучения</label>
                    <select name="degree_id" class="form-control degree" id="degree_id">
                        <option value="">Выберите</option>
                        <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(!is_null($degree_id) && $degree_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="direction_id">Область обучения</label>
                    <select name="direction_id" class="form-control direction" id="direction_id">
                        <option value="">Выберите</option>
                        <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(!is_null($direction_id) && $direction_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group" id="subdirection" style="display: none">
                    <label for="subdirection_id">Направление обучения</label>
                    <select name="subdirection_id" class="form-control subdirection" id="subdirection_id"></select>
                </div>
                <div class="form-group" id="specialty" style="display: none">
                    <label for="specialty_id">Специальность</label>
                    <select name="specialty_id" class="form-control specialty" id="specialty_id"></select>
                </div>
                <div class="form-group discipline" <?php if($type == 1 || $degree_id == 1 || is_null($degree_id)): ?> style="display: block;"
                        <?php else: ?> style="display: none;" <?php endif; ?>>
                    <label for="discipline">Профильный предмет</label>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="checkbox">
                            <label><input class="subject" name="subject_id" id="subject_id" type="checkbox" value="<?php echo e($k); ?>"> <?php echo e($v); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="form-group">
                    <label for="city_id">Город</label>
                    <select name="city_id" class="form-control city" id="city_id">
                        <option value="">Выберите</option>
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(!is_null($city_id) && $city_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div <?php if($type == 1 || $degree_id == 1 || is_null($degree_id)): ?> style="display: none;"
                     <?php else: ?> style="display: block;" <?php endif; ?> class="form-group sphere">
                    <label>Сфера направления</label>
                    <select name="program_id" class="form-control program" id="program_id">
                        <option value="">Выберите</option>
                        <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Тип учебного заведения</label>
                    <select name="type_id" class="form-control type" id="type_id">
                        <option value="">Выберите</option>
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="col-md-8 right-block result">
                <div class="sgs-list-header clearfix">
                    <div class="row">
                        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                            <p class="pull-left">Результат: найдено специальностей <span class="count"><?php echo e($count); ?></span></p>
                        </div>
                        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 mt--3">
                            <form class="form-horizontal sgs-list-sort" role="form">
                                <div class="form-group m-b-0">
                                    <label for="sortorder" class="sr-only">Сортировать по:</label>
                                    <select class="form-control sgs-sort" id="sortorder" name="sort">
                                        <option value="name">Наименование</option>
                                        <option value="town">Город</option>
                                        <option value="cost">Стоимость</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div>
                    <ul class="sgs-list-ul">
                        <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div>
                                    <h3>
                                        <a href="/poisk/view/<?php echo e($v->id); ?>">
                                            <strong><?php echo e($v->relSpecialty->cipher); ?> • <?php echo e($v->relSpecialty->name_ru); ?></strong>
                                            <span><?php echo e($v->relUniversity->name_ru); ?></span> • <?php echo e($v->relUniversity->relCity->name_ru); ?>

                                        </a>
                                    </h3>
                                    <table>
                                        <tbody class="main-table">
                                            <tr>
                                                <td>Степень обучения</td>
                                                <td><?php echo e($v->relSpecialty->relDegree->name_ru); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Стоимость обучение</td>
                                                <td><?php echo e(number_format($v->price, 0, '', ' ')); ?> тг.</td>
                                            </tr>
                                            <?php if($degree_id == 1 || !isset($degree_id)): ?> 
                                                <tr>
                                                    <td>Профильный предмет</td>
                                                    <td><?php echo e($v->relSpecialty->relSubject->name_ru); ?>, <?php echo e($v->relSpecialty->relSubject2->name_ru); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <?php if(in_array($degree_id, [2,3]) && !empty($v->relSpecialty->education_time)): ?> 
                                                <tr>
                                                    <td>Сфера направления</td>
                                                    <td><?php echo e($v->relSpecialty->relSphere->name_ru); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <td>Рейтинг специальности</td>
                                                <td><?php if(!empty($v->rating)): ?><?php echo e($v->rating); ?> место <?php else: ?> - <?php endif; ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="ajax-pagination">
                        <?php echo e($specialties->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>