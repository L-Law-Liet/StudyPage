<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="studiengangsuche sgs-detail" id="studiengangsuche">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <p class="back-link">
                    <a href="<?php echo e(url()->previous()); ?>"><span class="sprites back"></span>Вернуться к результатам поиска</a>
                </p>
                <div class="sgs-adress-header">
                    <h2>
                        <?php echo e($specialty->relSpecialty->cipher); ?> • <?php echo e($specialty->relSpecialty->name_ru); ?><br>
                        <?php echo e($specialty->relUniversity->name_ru); ?>

                        • <?php echo e($specialty->relUniversity->relCity->name_ru); ?>

                    </h2>
                </div>
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation"><a class="active" data-toggle="tab" href="#overview" role="tab" id="ui-tab-1" tabindex="0" aria-selected="true" aria-controls="overview">Обзор</a>
                    </li>
                    <?php if(!empty($specialty->passing_score_kz) || !empty($specialty->number_grants_kz) || !empty($specialty->passing_score_ru) || !empty($specialty->number_grants_ru) || !empty($specialty->passing_score)): ?>
                        <li role="presentation" class=""><a data-toggle="tab" href="#grant" role="tab" id="ui-tab-2" tabindex="-1" aria-selected="false" aria-controls="grant">Грант</a>
                        </li>
                    <?php endif; ?>
                    <?php $rating = \App\Models\CostEducation::getRating($specialty->relSpecialty->id) ?>
                    <?php if(count($rating) > 0): ?>
                        <li role="presentation" class=""><a data-toggle="tab" href="#rating" role="tab" id="ui-tab-3" tabindex="-1" aria-selected="false" aria-controls="rating">Рейтинг</a>
                        </li>
                    <?php endif; ?>
                    <li role="presentation" class=""><a data-toggle="tab" href="#doc" role="tab" id="ui-tab-4" tabindex="-1" aria-selected="false" aria-controls="doc">Документ</a>
                    </li>
                </ul>
            </div>
            <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                <div class="tab-content">
                    <div id="overview" class="tab-pane fade active in" role="tabpanel" tabindex="0" aria-hidden="false" aria-labelledby="ui-tab-1">
                        <h3>Язык обучения</h3>
                        <p><?php echo e($specialty->relLanguage->name_ru); ?></p>
                        <?php if(!empty($specialty->relSpecialty->education_time)): ?>
                            <h3>Срок обучения</h3>
                            <p><?php echo e($specialty->relSpecialty->education_time); ?></p>
                        <?php endif; ?>
                        <h3>Степень обучения</h3>
                        <p><?php echo e($specialty->relSpecialty->relDegree->name_ru); ?></p>
                        <h3>Стоимость обучения</h3>
                        <p><?php echo e(number_format($specialty->price, 0, '', ' ')); ?> тенге</p>

                        <?php if($specialty->relSpecialty->relDegree->id == 1): ?>
                            <h3>Профильный предмет</h3>
                            <p><?php echo e($specialty->relSpecialty->relSubject->name_ru); ?>, <?php echo e($specialty->relSpecialty->relSubject2->name_ru); ?></p>
                        <?php else: ?>
                            <h3>Сфера направления</h3>
                            <p><?php echo e((!is_null($specialty->relSpecialty->relSphere)) ? $specialty->relSpecialty->relSphere->name_ru : ''); ?></p>
                        <?php endif; ?>
                    </div>
                    <div id="grant" class="tab-pane fade" role="tabpanel" tabindex="-1" aria-hidden="true" aria-labelledby="ui-tab-2">
                        <?php if(!empty($specialty->passing_score_kz) && !empty($specialty->number_grants_kz)): ?>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th colspan="2" class="text-center">Казахское отделение</th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" class="text-center"><?php echo e($specialty->year); ?></th>
                                    </tr>
                                    <tr>
                                        <th class="text-center">Количество грантов</th>
                                        <th class="text-center">Проходной балл</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-center"><?php echo e($specialty->number_grants_kz); ?></td>
                                        <td class="text-center"><?php echo e($specialty->passing_score_kz); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php endif; ?>
                        <?php if(!empty($specialty->passing_score_ru) && !empty($specialty->number_grants_ru)): ?>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th colspan="2" class="text-center">Русское отделение</th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" class="text-center"><?php echo e($specialty->year); ?></th>
                                    </tr>
                                    <tr>
                                        <th class="text-center">Количество грантов</th>
                                        <th class="text-center">Проходной балл</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-center"><?php echo e($specialty->number_grants_ru); ?></td>
                                        <td class="text-center"><?php echo e($specialty->passing_score_ru); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php endif; ?>
                        <?php if(!empty($specialty->passing_score)): ?>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th class="text-center">Проходной балл на на платное обучение</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td class="text-center"><?php echo e($specialty->passing_score); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                    <div id="rating" class="tab-pane fade" role="tabpanel" tabindex="-1" aria-hidden="true" aria-labelledby="ui-tab-3">
                        <?php if(count($rating) > 0): ?>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>№</th>
                                        <th class="text-center">Наименование ВУЗа</th>
                                        <th class="text-center">Место</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($k+1); ?></td>
                                            <td><?php echo e($v->relUniversity->name_ru); ?></td>
                                            <td class="text-center"><?php echo e($v->total); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <?php if(!empty($specialty->source)): ?>
                                    <tfoot>
                                        <tr>
                                            <td colspan='3'><b>Источник:</b> <?php echo e($specialty->source); ?></td>
                                        </tr>
                                    </tfoot>
                                <?php endif; ?>
                            </table>
                        <?php endif; ?>
                    </div>
                    <div id="doc" class="tab-pane fade" role="tabpanel" tabindex="-1" aria-hidden="true" aria-labelledby="ui-tab-4">
                        <?php if(is_object($requirement)): ?> <?php echo $requirement->content_ru; ?> <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
                <div class="sgs-adress">
                    <h3>Контакты</h3>
                    <p><b><?php echo e($specialty->relUniversity->name_ru); ?></b></p>
                    <p><?php echo $specialty->relUniversity->subdivision; ?></p>
                    <p><?php echo e($specialty->relUniversity->address_ru); ?></p>
                    <p><?php echo e($specialty->relUniversity->postcode); ?> <?php echo e($specialty->relUniversity->relCity->name_ru); ?></p>
                    <p>Тел.: <?php echo e($specialty->relUniversity->phone); ?></p>
                    <p><?php echo e($specialty->relUniversity->email); ?></p>
                    <p><?php echo e($specialty->relUniversity->web_site); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>