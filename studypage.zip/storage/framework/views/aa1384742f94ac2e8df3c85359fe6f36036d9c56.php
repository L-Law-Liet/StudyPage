

<?php $__env->startSection('title', 'Обратная связь'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Обратная связь</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a href="/admin/callback/add" class="btn btn-success pull-right">Добавить</a>
                </div>
                <div class="box-body">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th width="2%">#</th>
                                <th>Имя</th>
                                <th>Email</th>
                                <th>Вопрос</th>
                                <th width="5%" colspan="3" class="text-center">Действие</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $callback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($callback->firstItem()+$k); ?></td>
                                <td><?php echo e($v->name); ?></td>
                                <td><?php echo e($v->email); ?></td>
                                <td><?php echo $v->question; ?></td>
                                <td>
                                    <a href="/admin/callback/view/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                                    </a>
                                </td>
                                <td>
                                    <a href="/admin/callback/add/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                                    </a>
                                </td>
                                <td>
                                    <a href="/admin/callback/delete/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td colspan = '2'>Количество <?php echo e($count); ?></td>
                            <td colspan = '3' class='text-center'><?php echo e($callback->links()); ?></td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>