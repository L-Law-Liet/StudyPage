

<?php $__env->startSection('title', 'Редактировать статью'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php
        $title = is_null($id) ? 'Добавить' : 'Редактировать'
    ?>
    <h1><?php echo e($title); ?> статью</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/article/add':"/admin/article/add/$id";
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-md-3">Заголовок</label>
                            <div class="col-md-9">
                                <input type="text" name="title" class="form-control" <?php if(is_object($article)): ?> value="<?php echo e($article->title); ?>" <?php endif; ?>>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Описание</label>
                            <div class="col-md-9">
                                <textarea name="description" class="form-control"><?php if(is_object($article)): ?> <?php echo e($article->description); ?> <?php endif; ?></textarea>
                            </div>
                        </div>
                        <div class="clearfix">
                            <button class="btn btn-success pull-right">Сохранить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>