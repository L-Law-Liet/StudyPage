<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="keywords" content="высшее, образование, в Казахстане, рейтинг, ВУЗов, документы для поступление в ВУЗы, ЕНТ" />
    <meta name="description" content="Unipage - высшее образование в Казахстане, рейтинг ВУЗов, документа для поступления, калькулятор прохождения ЕНТ" />

    <title>Unipage - высшее образование в Казахстане</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/slick.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" ></script>
    <?php echo $__env->yieldContent('js'); ?>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body oncontextmenu="return false" oncopy="return false;" oncontextmenu="return false" onselectstart="return false;">
<div id="app">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <!-- На главной странице множество js не работают из-за отсутствия токена -->
    <div id="header">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                    <div class="logos clearfix">
                        <h1>
                            <a href="/">
                                <img src="/img/logo_landofideas_en.png">
                            </a>
                            <span class="sr-only"></span>
                        </h1>
                        <span class="sr-only">.</span>
                        <a href="/" class="extra-header-logo" title="Never stop learning">
                            <img src="/img/logo_infos_en.png" id="slogan"></a>
                        <span class="sr-only">.</span>
                    </div>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                    <ul class="social-icons float-right">
                        <li><a id="in" href="#"></a></li>
                        <li><a id="yu" href="#"></a></li>
                        <li><a id="vk" href="#"></a></li>
                        <li><a id="fb" href="#"></a></li>
                        <li><a id="tw" href="#"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel navbar-unipage">
        <div class="container">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php if(Request::path() == 'bachelor'): ?> active <?php endif; ?>" href="<?php echo e(route('bachelor')); ?>?type=1">Бакалавриат</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if(Request::path() == 'master'): ?> active <?php endif; ?>" href="<?php echo e(route('master')); ?>?type=2">Магистратура</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if(Request::path() == 'higher'): ?> active <?php endif; ?>" href="<?php echo e(route('higher')); ?>?type=3">Докторантура</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if(Request::path() == 'calculator'): ?> active <?php endif; ?>" href="<?php echo e(route('calculator')); ?>">Калькулятор ЕНТ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if(Request::path() == 'rating/1'): ?> active <?php endif; ?>" href="/rating/1"><?php echo e(trans('general.rating_he')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="py-4">
        <?php echo $__env->make('error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <div class="minimap">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <h2 class="sr-only">main navigation</h2>
                    <ul>
                        <li>
                            <span>Степень</span>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('bachelor')); ?>?type=1">Бакалавриат</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('master')); ?>?type=2">Магистратура</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('higher')); ?>?type=3">Докторантура</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <span>Поступление</span>
                            <ul>
                                <li>
                                    <a href="/city/view/2">Города</a>
                                </li>
                                <li>
                                    <a href="/article/6">ЕНТ / КТА</a>
                                </li>
                                <li>
                                    <a href="/rating/1">Рейтинг ВУЗов</a>
                                </li>
                                <li>
                                    <a href="#">Калькулятор ЕНТ</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <span>Соглашение</span>
                            <ul>
                                <li>
                                    <a href="/article/5">ВУЗам</a>
                                </li>
                                <li>
                                    <a href="/article/4">Пользователям</a>
                                </li>
                                <li>
                                    <a href="/article/3">Рекламодателям</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <span>Контакты</span>
                            <ul>
                                <li>
                                    <a href="/article/2">О сайте</a>
                                </li>
                                <li>
                                    <a href="/article/1">Добавить ВУЗ</a>
                                </li>
                                <li>
                                    <a href="/callback">Обратная связь</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container">
            <p class="text-center m-t-35">&copy; Unipage <?=date('Y')?> | Все права защищены</p>
            <!-- Yandex.Metrika counter -->
            <script type="text/javascript" >
                (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
                    m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
                (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

                ym(52723207, "init", {
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            </script>
            <noscript><div><img src="https://mc.yandex.ru/watch/52723207" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
            <!-- /Yandex.Metrika counter -->
        </div>
    </div>
    <div class="container">
        <a href="#app" id="bottom" class="sprites page-top" title="Back to top" style="display: block;">
            <span class="sr-only">Back to top</span>
        </a>
    </div>
    <a data-toggle="modal" data-target="#callbackModal">
        <div id="callback">
            <i class="fas fa-comments fa-2x"></i>
            <div id="callback-imgphone"></div>
            <div id="callback-wave"></div>
        </div>
    </a>
    <div class="modal" id="callbackModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST" action=<?php echo e(URL::action("IndexController@postCallback")); ?>>
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title">Связаться с нами</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group row">
                            <label class="col-md-3">Ваше имя</label>
                            <div class="col-md-9">
                                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Электронная почта</label>
                            <div class="col-md-9">
                                <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Сообщение</label>
                            <div class="col-md-9">
                                <textarea rows="4" name="question" class="form-control"><?php echo e(old('question')); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-success float-right">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
</body>
</html>
