<div class="sgs-list-header clearfix">
    <div class="row">
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
            <p class="pull-left">Результат: найдено специальностей <span class="count"><?php echo e($count); ?></span></p>
        </div>
        <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 mt--3">
            <form class="form-horizontal sgs-list-sort" role="form">
                <div class="form-group m-b-0">
                    <label for="sortorder" class="sr-only">Сортировать по:</label>
                    <select class="form-control sgs-sort" id="sortorder" name="sort">
                        <option value="name" <?php if($sort == 'name'): ?> selected <?php endif; ?>>Наименование</option>
                        <option value="town" <?php if($sort == 'town'): ?> selected <?php endif; ?>>Город</option>
                        <option value="cost" <?php if($sort == 'cost'): ?> selected <?php endif; ?>>Стоимость</option>
                    </select>
                </div>
            </form>
        </div>
    </div>
</div>
<div>
    <ul class="sgs-list-ul">
        <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <div style="margin-bottom: 30px;">
                    <h3>
                        <a href="/poisk/view/<?php echo e($v->id); ?>">
                            <strong><? if ($v->relSpecialty->cipher != null AND $v->relSpecialty->cipher != 'none') { ?><?php echo e($v->relSpecialty->cipher); ?> •<? } ?> <?php echo e($v->relSpecialty->name_ru); ?></strong>
                            <span><?php echo e($v->relUniversity->name_ru); ?></span> • <?php echo e($v->relUniversity->relCity->name_ru); ?>

                        </a>
                    </h3>
                    <table>
                        <tbody class="main-table">
                            <tr>
                                <td>Степень обучения</td>
                                <td><?php echo e($v->relSpecialty->relDegree->name_ru); ?></td>
                            </tr>
                            <tr>
                                <td>Стоимость обучение</td>
                                <td><?php echo e(number_format($v->price, 0, '', ' ')); ?> тг. <?php if($v->price != 0): ?>/ год <?php endif; ?></td>
                            </tr>
                            <?php if($degree_id == 1 OR isset($v->relSpecialty->relSubject->name_ru)): ?> 
                            <tr>
                                <td>Профильный предмет</td>
                                <td><?php echo e($v->relSpecialty->relSubject->name_ru); ?>, <?php echo e($v->relSpecialty->relSubject2->name_ru); ?></td>
                            </tr>
                            <?php else: ?>
                            <tr>
                                <td>Сфера направления</td>
                                <td><?php echo e($v->relSpecialty->relSphere->name_ru); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td>Срок обучения</td>
                                <td><?php echo e($v->relSpecialty->education_time); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="ajax-pagination">
        <?php echo e($specialties->links()); ?>

    </div>
</div>