<?php $__env->startSection('content'); ?>
    <div class="content">
        <a href="/admin/subjects/add" class="btn btn-success float-right">Добавить</a>
        <table class="table table-hover">
            <thead>
                 <tr>
                    <td>#</td>
                    <td>Название</td>
                    <td>Действие</td>
                 </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subjects->firstItem()+$k); ?></td>
                    <td><a href="/admin/subjects/view/<?php echo e($v->id); ?>"><?php echo e($v->name_ru); ?></a></td>
                    <td><a href="/admin/subjects/add/<?php echo e($v->id); ?>"><i class="far fa-edit"></i></a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td>Количество <?php echo e($count); ?></td>
                    <td colspan = '2' class='text-center'><?php echo e($subjects->links()); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>