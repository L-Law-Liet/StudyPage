<?php $__env->startSection('title', 'Ответить на вопрос'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Ответить на вопрос</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/callback/add':"/admin/callback/add/$id";
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-md-3">Имя</label>
                            <div class="col-md-9">
                                <input type="text" name="name" class="form-control" <?php if(is_object($callback)): ?> value="<?php echo e($callback->name); ?>" <?php endif; ?>>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Email</label>
                            <div class="col-md-9">
                                <input type="text" name="email" class="form-control" <?php if(is_object($callback)): ?> value="<?php echo e($callback->email); ?>" <?php endif; ?>>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Вопрос</label>
                            <div class="col-md-9">
                                <textarea name="question" class="form-control"><?php if(is_object($callback)): ?> <?php echo e($callback->question); ?> <?php endif; ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Ответ</label>
                            <div class="col-md-9">
                                <textarea name="answer" class="form-control"><?php if(is_object($callback)): ?> <?php echo e($callback->answer); ?> <?php endif; ?></textarea>
                            </div>
                        </div>
                        <div class="clearfix">
                            <button class="btn btn-success pull-right">Сохранить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>