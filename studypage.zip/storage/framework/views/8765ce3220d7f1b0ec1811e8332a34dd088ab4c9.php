<p>
    <? if (!empty($name)) { ?>
    Имя: <strong><?php echo e($name); ?></strong><br>
    <? } ?>
    <? if (!empty($phone)) { ?>
    Контактный телефон: <strong><?php echo e($phone); ?></strong><br>
    <? } ?>
    <? if (!empty($email)) { ?>
    Электронная почта: <strong><?php echo e($email); ?></strong><br>
    <? } ?>
    <? if (!empty($question)) { ?>
    Сообщение: <strong><?php echo e($question); ?></strong>
    <? } ?>
    <? if (!empty($contact_name)) { ?>
    Имя контактного лица: <strong><?php echo e($contact_name); ?></strong><br>
    <? } ?>
    <? if (!empty($university_name)) { ?>
    Название учебного заведения: <strong><?php echo e($university_name); ?></strong><br>
    <? } ?>
    <? if (!empty($contact_phone)) { ?>
    Контактный телефон: <strong><?php echo e($contact_phone); ?></strong><br>
    <? } ?>
    <? if (!empty($email2)) { ?>
    Электронная почта: <strong><?php echo e($email2); ?></strong>
    <? } ?>
</p>