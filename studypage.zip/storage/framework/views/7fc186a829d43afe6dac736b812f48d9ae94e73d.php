<?php $__env->startSection('title', 'Специальности'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Специальности</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a href="/admin/specialty/add" class="btn btn-success pull-right">Добавить</a>
                </div>
                <div class="box-body">
                    <table class="table table-hover">
                        <thead>
                             <tr>
                                <th width="2%">#</th>
                                <th>Шифр</th>-
                                <th>Название</th>
                                <th>Сфера направления</th>
                                <th colspan="3" class="text-center">Действие</th>
                             </tr>
                             <tr>
                                 <?php echo e(Form::open(['method' => 'GET'])); ?>

                                 <td></td>
                                 <td><input class="form-control" name="cipher"></td>
                                 <td><input class="form-control" name="name_ru"></td>
                                 <td>
                                     <select name="sphere_id" class="form-control">
                                         <option></option>
                                         <?php $__currentLoopData = $sphere; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </select>
                                 </td>
                                 <td><input class="form-control" name="education_time"></td>
                                 <td colspan="3" class="text-center"><button type="submit" class="btn btn-success">Фильтр</button></td>
                                 <?php echo e(Form::close()); ?>

                             </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($specialties->firstItem()+$k); ?></td>
                                <td><?php echo e($v->cipher); ?></td>
                                <td><?php echo e($v->name_ru); ?></td>
                                <td><?php echo e((!is_null($v->relSphere)) ? $v->relSphere->name_ru : ''); ?></td>
                                <td><?php echo e($v->education_time); ?></td>
                                <td>
                                    <a href="/admin/specialty/view/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                                    </a>
                                </td>
                                <td>
                                    <a href="/admin/specialty/add/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                                    </a>
                                </td>
                                <td>
                                    <a class="nDBtn" data-href="/admin/specialty/delete/<?php echo e($v->id); ?>">
                                        <i class="glyphicon glyphicon-trash" title="Удалить"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan = '2'>Количество <?php echo e($count); ?></td>
                                <td colspan = '3' class='text-center'><?php echo e($specialties->links()); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>