<?php $__env->startSection('title', 'Редактировать специальность'); ?>

<?php $__env->startSection('content_header'); ?>
    <?php
        $title = is_null($id) ? 'Добавить' : 'Редактировать'
    ?>
    <h1><?php echo e($title); ?> специальность</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/specialty/add':"/admin/specialty/add/$id";
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <form action="<?php echo e($action); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-md-3">Шифр специальности</label>
                            <div class="col-md-9">
                                <input type="text" name="cipher" class="form-control" <?php if(is_object($specialty)): ?> value="<?php echo e($specialty->cipher); ?>" <?php endif; ?> >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Наименование</label>
                            <div class="col-md-9">
                                <input type="text" name="name_ru" class="form-control" <?php if(is_object($specialty)): ?> value="<?php echo e($specialty->name_ru); ?>" <?php endif; ?> >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Область обучения</label>
                            <div class="col-md-9">
                                <select name="direction_id" class="form-control admin-direction">
                                    <option></option>
                                    <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($specialty) && !empty($specialty->subdirection_id) && $specialty->relSubdirection->relDirection->id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row" id="subdirection" <?php if(!is_object($specialty) && empty($specialty->subdirection_id)): ?> style="display: none" <?php endif; ?>>
                            <label class="col-md-3">Направление обучения</label>
                            <div class="col-md-9">
                                <select name="subdirection_id" class="form-control subdirection" id="subdirection_id">
                                <?php if(!is_object($specialty) && empty($specialty->subdirection_id)): ?>
                                </select>
                                <?php else: ?>
                                    <option></option>
                                    <?php $__currentLoopData = $subdirections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($specialty) && $specialty->subdirection_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Профильный предмет</label>
                            <div class="col-md-9">
                                <select name="subject_id" class="form-control">
                                    <option></option>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($specialty) && $specialty->subject_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Второй профильный предмет</label>
                            <div class="col-md-9">
                                <select name="subject_id2" class="form-control">
                                    <option></option>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($specialty) && $specialty->subject_id2 == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Степень</label>
                            <div class="col-md-9">
                                <select name="degree_id" class="form-control admin-degree">
                                    <option></option>
                                    <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($specialty) && $specialty->degree_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row admin-sphere" style="display: none">
                            <label class="col-md-3">Сфера направления</label>
                            <div class="col-md-9">
                                <select name="sphere_id" class="form-control">
                                    <option></option>
                                    <?php $__currentLoopData = $sphere; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(is_object($specialty) && $specialty->sphere_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3">Срок обучения</label>
                            <div class="col-md-9">
                                <input type="text" name="education_time" class="form-control" <?php if(is_object($specialty)): ?> value="<?php echo e($specialty->education_time); ?>" <?php endif; ?> >
                            </div>
                        </div>
                        <div class="clearfix">
                            <button class="btn btn-success pull-right">Сохранить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>