<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/rating/add':"/admin/rating/add/$id";
    ?>
    <div class="content">
        <h4>Добавить рейтинг</h4>
        <form action="<?php echo e($action); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-md-3">Направление</label>
                <div class="col-md-9">
                    <select name="category_id" class="form-control">
                        <option value=""></option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(is_object($rating) && $rating->category_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Университет</label>
                <div class="col-md-9">
                    <input type="text" name="name" class="form-control university_find" <?php if(is_object($rating)): ?> value="<?php echo e($rating->relUniversity->name_ru); ?>" <?php endif; ?>>
                    <input type="hidden" name="university_id" id="university_id" <?php if(is_object($rating)): ?> value="<?php echo e($rating->university_id); ?>" <?php endif; ?>>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Город</label>
                <div class="col-md-9">
                    <select name="city_id" class="form-control city" id="city_id">
                        <option value=""></option>
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(is_object($rating) && $rating->city_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Итого (Балл)</label>
                <div class="col-md-9">
                    <input type="text" name="overall_rating" class="form-control" <?php if(is_object($rating)): ?> value="<?php echo e($rating->overall_rating); ?>" <?php endif; ?>>
                </div>
            </div>
            <div class="clearfix">
                <button class="btn btn-success pull-right">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>