<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/subdirection/add':"/admin/subdirection/add/$id";
    ?>
    <div class="content">
        <h4>Добавить направление обучения</h4>
        <form action="<?php echo e($action); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-md-3">Направление обучения</label>
                <div class="col-md-9">
                    <select name="direction_id" class="form-control city">
                        <option></option>
                        <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(is_object($subdirections) && $subdirections->direction_id == $k): ?> selected <?php endif; ?> value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Наименование</label>
                <div class="col-md-9">
                    <input type="text" name="name_ru" class="form-control" <?php if(is_object($subdirections)): ?> value="<?php echo e($subdirections->name_ru); ?>" <?php endif; ?> >
                </div>
            </div>
            <div class="clearfix">
                <button class="btn btn-success pull-right">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>