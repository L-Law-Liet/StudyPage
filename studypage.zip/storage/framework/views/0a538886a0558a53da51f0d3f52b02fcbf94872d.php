<?php $__env->startSection('css'); ?>
    <style>
        main.mt-5 {
            margin-top: 0 !important;
        }
        main.py-4 {
            padding-top: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('subnav'); ?>
    <div class="container">
        <div class="college-view-nav">
            <a href="<?php echo e(url()->previous()); ?>"><img class="mr-2" src="<?php echo e(asset('img/arrow-left.svg')); ?>" alt=""><span>Вернуться к списку колледжей /</span></a><span class="color-2D7ABF"> Университет Нархоз</span>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-8">
                <div id="college-view-right">
                    <h3 class="text-center">СОТРУДНИЧЕСТВО</h3>
                    <div>
                        <div class="cv-text">
                            <p>
                                Согласно мнению известных философов, дедуктивный метод естественно
                                порождает и обеспечивает мир, tertium nоn datur. Надстройка нетривиальна.
                                Структурализм абстрактен. Интеллект естественно понимает под собой интеллигибельный
                                закон внешнего мира, открывая новые горизонты. Интеллект естественно понимает под
                                собой интеллигибельный за
                            </p>
                            <p>
                                Дискретность амбивалентно транспонирует гравитационный парадокс.
                                Сомнение рефлектирует естественный закон исключённого третьего..
                                Импликация, следовательно, контролирует бабувизм, открывая новые горизонты.
                                Интеллект естественно понимает под собой интеллигибельный закон внешнего мира,
                                открывая новые горизонты. Деду
                            </p>
                            <p>
                                Дискретность амбивалентно транспонирует гравитационный парадокс. Согласно мнению
                                известных философов, дедуктивный метод естественно порождает и обеспечивает мир,
                                tertium nоn datur. Дедуктивный метод решительно представляет собой бабувизм.
                                Аксиома силлогизма, по определению, представляет собой неоднозначный предмет деятельнос
                            </p>
                            <p>
                                Дискретность амбивалентно транспонирует гравитационный парадокс. Согласно мнению
                                известных философов, дедуктивный метод естественно порождает и обеспечивает мир,
                                tertium nоn datur. Дедуктивный метод решительно представляет собой бабувизм.
                                Аксиома силлогизма, по определению, представляет собой неоднозначный предмет деятельнос
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <ul class="cv-list">
                    <li><a href="<?php echo e(url('college-view')); ?>" <?php if(($class ?? '') == 'view'): ?> class="color-2D7ABF" <?php endif; ?> > <?php if(($class ?? '') == 'view'): ?> <img src="img/multi-profile-play.svg" alt=""> <?php endif; ?> Университет Нархоз</a></li>
                    <li><a href="<?php echo e(url('college-achievements')); ?>" <?php if(($class ?? '') == 'achieve'): ?> class="color-2D7ABF" <?php endif; ?>  > <?php if(($class ?? '') == 'achieve'): ?> <img src="img/multi-profile-play.svg" alt=""> <?php endif; ?> Достижения</a></li>
                    <li><a href="<?php echo e(url('college-coop')); ?>" <?php if(($class ?? '') == 'coop'): ?> class="color-2D7ABF" <?php endif; ?>  > <?php if(($class ?? '') == 'coop'): ?> <img src="img/multi-profile-play.svg" alt=""> <?php endif; ?> Сотрудничество</a></li>
                    <li><a href="#">Рейтинг</a></li>
                    <li><a href="#">Гранты / Скидки</a></li>
                    <li><a href="#">Образовательные программы</a></li>
                    <li><a href="#">Документы для поступления</a></li>
                    <li><a href="#">Контакты</a></li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>