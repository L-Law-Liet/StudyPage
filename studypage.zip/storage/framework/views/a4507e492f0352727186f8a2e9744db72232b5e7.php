

<?php $__env->startSection('title', 'Просмотр специальности'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Просмотр специальности</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <table class="table table-striped table-view">
                        <tr>
                            <th>Шифр специальности</th>
                            <td><?php echo e($specialty->cipher); ?></td>
                        </tr>
                        <tr>
                            <th>Наименование</th>
                            <td><?php echo e($specialty->name_ru); ?></td>
                        </tr>
                        <tr>
                            <th>Область обучения</th>
                            <td><?php if(is_object($specialty->relSubdirection)): ?><?php echo e($specialty->relSubdirection->relDirection->name_ru); ?><?php endif; ?></td>
                        </tr>
                        <tr>
                            <th>Направление обучения</th>
                            <td><?php if(is_object($specialty->relSubdirection)): ?><?php echo e($specialty->relSubdirection->name_ru); ?><?php endif; ?></td>
                        </tr>
                        <tr>
                            <th>Профильный предмет</th>
                            <td><?php if(is_object($specialty->relSubject)): ?><?php echo e($specialty->relSubject->name_ru); ?><?php endif; ?></td>
                        </tr>
                        <tr>
                            <th>Степень</th>
                            <td><?php if(is_object($specialty->relDegree)): ?><?php echo e($specialty->relDegree->name_ru); ?><?php endif; ?></td>
                        </tr>
                        <tr>
                            <th>Срок обучения</th>
                            <td><?php echo e($specialty->education_time); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>