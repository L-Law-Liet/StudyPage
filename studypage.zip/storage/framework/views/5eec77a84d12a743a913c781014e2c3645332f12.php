<div class="row">
    <div class="col-md-8 offset-md-2 m-t-10">
        <form action=<?php echo e(URL::action("IndexController@postProposal")); ?> method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-md-3">Электронная почта</label>
                <div class="col-md-9">
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Контактный телефон</label>
                <div class="col-md-9">
                    <input type="text" name="contact_phone" class="form-control" value="<?php echo e(old('contact_phone')); ?>">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Название учебного заведения</label>
                <div class="col-md-9">
                    <input type="text" name="university_name" class="form-control" value="<?php echo e(old('university_name')); ?>">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Имя контактного лица</label>
                <div class="col-md-9">
                    <input type="text" name="contact_name" class="form-control" value="<?php echo e(old('contact_name')); ?>">
                </div>
            </div>
            <div class="clearfix">
                <button class="btn btn-success float-right">Отправить</button>
            </div>
        </form>
    </div>
</div>
