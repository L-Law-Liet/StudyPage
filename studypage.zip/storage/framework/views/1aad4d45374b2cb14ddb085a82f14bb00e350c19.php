<?php $__env->startSection('content'); ?>
    <div class="content">
        <table class="table table-striped table-view">
            <tr>
                <th>Наименование ВУЗа</th>
                <td><?php echo e($university->name_ru); ?></td>
            </tr>
            
            <tr>
                <th>Город</th>
                <td><?php echo e($city->name_ru); ?></td>
            </tr>
            <tr>
                <th>Адрес</th>
                <td><?php echo e($university->address_ru); ?></td>
            </tr>
            
            <tr>
                <th>Телефон</th>
                <td><?php echo e($university->phone); ?></td>
            </tr>
            <tr>
                <th>Краткая информация</th>
                <td><?php echo e($university->information_ru); ?></td>
            </tr>
            <tr>
                <th>Год</th>
                <td><?php echo e($cost->year); ?></td>
            </tr>
            <tr>
                <th>Рейтинг специальности</th>
                <td><?php echo e($cost->rating); ?></td>
            </tr>
            <tr>
                <th>Итого</th>
                <td><?php echo e($cost->total); ?></td>
            </tr>
            <tr>
                <th>Количество грантов на русское отделение</th>
                <td><?php echo e($cost->number_grants_ru); ?></td>
            </tr>
            <tr>
                <th>Количество грантов на казахское отделение</th>
                <td><?php echo e($cost->number_grants_kz); ?></td>
            </tr>
            <tr>
                <th>Проходной балл на русское отделение</th>
                <td><?php echo e($cost->passing_score_ru); ?></td>
            </tr>
            <tr>
                <th>Проходной балл на казахское отделение</th>
                <td><?php echo e($cost->passing_score_kz); ?></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>