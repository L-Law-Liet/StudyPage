<?php $__env->startSection('content'); ?>
    <div class="container pt-2">
        <div class="row">
            <div class="col-md-8">
                <?php if(substr($class, 1)): ?>
                <h4><?php echo e(mb_strtoupper(App\Profile::find(substr($class, 1))->name)??''); ?></h4>
                <?php endif; ?>
                <table class="table table-striped table-view">
                    <thead>
                    <tr>
                        <th class="w-30px">№</th>
                        <th>Наименование <?php echo e(($class[0] == 1)?'ВУЗа':'Колледжа'); ?></th>
                        <th width="20%;">Город</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $us; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($u->name_ru); ?></td>
                            <td style=""><?php echo e($u->relCity->name_ru??''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="3"><b>Источник:</b> Независимое агентство аккредитации и рейтинга (НААР-2019)</td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4 pl-0">
                <ul class="multi-profile-list">
                <?php $__currentLoopData = \App\Profile::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('university/list/multiprofile', [$type, $p->id])); ?>" <?php if(($class ?? '') == $type.$p->id): ?> class="color-C11800" <?php endif; ?> > <?php if(($class ?? '') == $type.$p->id): ?> <img src="<?php echo e(asset('img/arrow-dots-red.svg')); ?>" alt=""> <?php else: ?> <img src="<?php echo e(asset('img/arrow-dots-black.svg')); ?>" alt=""> <?php endif; ?> <?php echo e($p->name); ?> </a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>