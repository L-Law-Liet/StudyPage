<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/cityslider/add':"/admin/cityslider/add/$id";
    ?>
    <div class="content">
        <h4>Добавить город</h4>
        <form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-md-3">Наименование города</label>
                <div class="col-md-9">
                    <input type="text" name="name_ru" class="form-control" <?php if(is_object($cityslider)): ?> value="<?php echo e($cityslider->name_ru); ?>" <?php endif; ?>>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Анонс</label>
                <div class="col-md-9">
                    <input type="text" name="announce" class="form-control" <?php if(is_object($cityslider)): ?> value="<?php echo e($cityslider->announce); ?>" <?php endif; ?>>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Описание</label>
                <div class="col-md-9">
                    <textarea name="description" class="form-control"><?php if(is_object($cityslider)): ?> <?php echo e($cityslider->description); ?> <?php endif; ?></textarea>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Изображение</label>
                <div class="col-md-9">
                    <input type="file" name="image">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-md-3">Включить</label>
                <div class="col-md-9">
                    <select name="active" class="form-control">
                        <option <?php if(is_object($cityslider) && $cityslider->active == 1): ?> selected <?php endif; ?> value="<?php echo e(1); ?>">Да</option>
                        <option <?php if(is_object($cityslider) && $cityslider->active == 0): ?> selected <?php endif; ?> value="<?php echo e(0); ?>">Нет</option>
                    </select>
                </div>
            </div>
            <div class="clearfix">
                <button class="btn btn-success pull-right">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>