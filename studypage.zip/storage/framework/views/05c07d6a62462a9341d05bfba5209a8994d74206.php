<?php if($paginator->hasPages()): ?>
    <ul class="pagination" role="navigation">
        
        <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->getFromJson('pagination.previous'); ?>">
                <span class="page-link" aria-hidden="true">&lsaquo;</span>
            </li>
        <?php else: ?>
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->getFromJson('pagination.previous'); ?>">&lsaquo;</a>
            </li>
        <?php endif; ?>

        <? $c = 0; ?>
        <? $i = 0; ?>
        <? $s = 0; ?>
        <? $lastL = 0; ?>
        
        <? $count = count($elements); ?>
        <? $lK = key(end($elements)) + 1;?>
        <? $last = 0; ?>
        <? $fN = 0; ?>
        <? $fD = 0; ?>
        <? $fL = 0; ?>
        <? $s3F = 0; ?>
            <? $eF = 0; ?>
        <? //echo $lK; ?>
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?
                if (!is_string($element)) {
                    $countNext = count($element);
                    if (is_array($element)) {
                        $last = end($element);
                        $last = array_search($last, $element);
                    }
                }
            ?>
            
            <?php if(is_string($element)): ?>
                <li class="page-item disabled tTo" aria-disabled="true"><span class="page-link"><?php echo e($element); ?></span></li>
                <? $s++; ?>
            <?php endif; ?>

            

            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($page); ?></span></li>
                    <?php else: ?>
                        <?
                            $cP = $paginator->currentPage();
                            $g = 0;
                        ?>
                        <? if ($count == 5) { ?>

                            <? if ($i == 0) { ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <? } ?>

                            <? if ((($page - $cP) < 2 AND ($cP - $page) < 2)) { ?>
                                <? $g = 1; ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <? } ?>
                            <? if ((($page - $cP) < 2 AND $g == 0 AND ($page >= $cP)) OR $lK == $page) { ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <? } ?>
                        <? } else if ($count == 3) { ?>

                            <? if ($cP == 4 AND $i == 0) { ?>
                                <li class="page-item"><a class="page-link" href="https://studypage.net/ajax/spacialty?page=1">1</a></li>
                            <? } ?>

                            <? if ((($page - $cP) < 2 AND ($cP - $page) < 3)) { ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                <? if (($last - $cP) > 1 AND $last > 8 AND $page > $cP) { ?>
                                    <? if (($last - $cP) != 2 AND ($last - $cP) != 3) { ?>
                                        <li class="page-item disabled tTo" aria-disabled="true"><span class="page-link">...</span></li>
                                    <? } ?>
                                    <? if (($last - $cP) == 3) { ?>
                                        <li class="page-item"><a class="page-link" href="https://studypage.net/ajax/spacialty?page=<?php echo e($last-1); ?>"><?php echo e($last-1); ?></a></li>
                                    <? } ?>
                                    <li class="page-item"><a class="page-link" href="https://studypage.net/ajax/spacialty?page=<?php echo e($last); ?>"><?php echo e($last); ?></a></li>
                                <? } ?>
                            <? } ?>
                            <? if (($last == $page AND ($page - $cP) > 8) OR ($last == $page AND $last > 8 AND $last <= 14 AND ($page - $cP) > 5)) { ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <? } ?>

                            <? if ($i == 0 AND $fN == 0 AND $cP != 2 AND $cP != 3 AND $cP != 4) { ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                <? $fN = 1; ?>
                            <? } ?>
                            <? if ($i == 1 AND $cP != 3 AND $cP != 1 AND $cP < 8) { ?>
                                <? if ($cP != 5 AND $cP != 4 AND $cP != 7) { ?>
                                    <li class="page-item disabled tTo" aria-disabled="true"><span class="page-link">...</span></li>
                                <? } else if ($cP == 5) { ?>
                                    <li class="page-item"><a class="page-link" href="https://studypage.net/ajax/spacialty?page=2">2</a></li>
                                <? } ?>
                            <? } ?>

                        <? } else { ?>
                            <? if ($countNext > 6) { ?>
                                <? if (($cP - $page) > 2 AND $fD == 0) { ?>
                                    <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                    <? if (($cP - $page) > 3) { ?>
                                        <? if ($cP != 5) { ?>
                                            <li class="page-item disabled tTo" aria-disabled="true"><span class="page-link">...</span></li>
                                        <? } else { ?>
                                            <li class="page-item"><a class="page-link" href="https://studypage.net/ajax/spacialty?page=2">2</a></li>
                                        <? } ?>
                                    <? } ?>
                                    <? $fD = 1; ?>
                                <? }?>
                                <? if (($page - $cP) < 3 AND ($cP - $page) < 3 AND $last > 8) { ?>
                                    <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                    <?if ($page == $countNext) { $fL = 1; } ?>
                                <? } ?>
                                <? if ($page == $countNext AND ($page - $cP > 2) AND ($countNext - $cP) > 3) { ?>
                                    <? if (($last - $cP) != 4) { ?>

                                    <li class="page-item disabled tTo" aria-disabled="true"><span class="page-link">...</span></li>
                                     <? } else { ?>
                                        <li class="page-item"><a class="page-link" href="https://studypage.net/ajax/spacialty?page=<?php echo e($last-1); ?>"><?php echo e($last-1); ?></a></li>

                                    <? } ?>
                                    <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>

                                <? } ?>
                                <? if (($countNext - $cP) <= 3 AND $countNext == $page AND $fL == 0) { ?>
                                    <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                                <? } ?>
                            <? } else { ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <? } ?>
                        <? } ?>
                    <?php endif; ?>
                    <? $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <? $c++; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->getFromJson('pagination.next'); ?>">&rsaquo;</a>
            </li>
        <?php else: ?>
            <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->getFromJson('pagination.next'); ?>">
                <span class="page-link" aria-hidden="true">&rsaquo;</span>
            </li>
        <?php endif; ?>
    </ul>
<?php endif; ?>
