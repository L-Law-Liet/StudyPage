<?php $__env->startSection('content'); ?>
    <?php
        $action = is_null($id)?'/admin/subjects/add':"/admin/subjects/add/$id";
    ?>
    <div class="content">
        <h4>Добавить предмет</h4>
        <form action="<?php echo e($action); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-3">Наименование на русском</label>
                <div class="col-9">
                    <input type="text" name="name_ru" class="form-control" <?php if(is_object($subject)): ?> value="<?php echo e($subject->name_ru); ?>" <?php endif; ?> >
                </div>
            </div>
            <div class="form-group row">
                <label class="col-3">Наименование на казахском</label>
                <div class="col-9">
                    <input type="text" name="name_kz" class="form-control" <?php if(is_object($subject)): ?> value="<?php echo e($subject->name_kz); ?>" <?php endif; ?> >
                </div>
            </div>
            <div class="clearfix">
                <button class="btn btn-success float-right">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>