<?php $__env->startSection('css'); ?>
    <style>
        main.mt-5 {
            margin-top: 0 !important;
        }
        main.py-4 {
            padding-top: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('college/subnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
        <div class="row">
            <div class="col-8">
                <div id="college-view-right">
                    <h3 class="text-center"><?php echo e($university->name_ru); ?></h3>
                    <div>
                        <div class="d-flex justify-content-between">
                            <div class="w-37">
                                <div class="cv-img-div">
                                    <img src="<?php echo e(asset('img/'.$university->image)); ?>" alt="">
                                </div>
                                <div class="under-cv-img-div mb-2">
                                    <p class="m-1"><b>Общежитие: </b><?php echo e(($university->dormitory)?'Да':'Нет'); ?></p>
                                    <p class="m-1"><b>Военная кафедра: </b><?php echo e(($university->military_dep)?'Да':'Нет'); ?></p>
                                    <p class="m-1"><b>Веб-сайт: </b><u><?php echo e(ltrim($university->web_site, 'Website:')); ?></u></p>
                                </div>
                            </div>
                            <div class="w-63 ml-4 pr-0">
                                <p class="cv-text">
                                    <?php echo e($university->short_description); ?>

                                </p>
                            </div>
                        </div>
                        <div class="cv-text cv-content">
                            <p>
                             <?php echo e($university->description); ?>

                            </p>
                        </div>
                        <div class="cv-media cv-content p-3">
                            ВИДЕО
                            <div class="d-flex justify-content-between position-relative">
                                <div class="position-absolute ml-2"
                                style="top: 33%;">
                                    <img src="<?php echo e(asset('img/media-arrow-left.svg')); ?>" alt="">
                                </div>
                                <div class="media-div"></div>
                                <div class="media-div"></div>
                                <div class="media-div"></div>
                                <div class="media-div"></div>
                                <div class="media-div"></div>
                                <div class="position-absolute mr-2"
                                     style="top: 33%; right: 0%">
                                    <img src="<?php echo e(asset('img/media-arrow-right.svg')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="cv-media cv-content p-3">
                            ГАЛЕРЕЯ
                            <div class="d-flex justify-content-between position-relative">
                                <div class="position-absolute ml-2"
                                     style="top: 33%;">
                                    <img src="<?php echo e(asset('img/media-arrow-left.svg')); ?>" alt="">
                                </div>
                                <div class="media-div"></div>
                                <div class="media-div"></div>
                                <div class="media-div"></div>
                                <div class="media-div"></div>
                                <div class="media-div"></div>
                                <div class="position-absolute mr-2"
                                     style="top: 33%; right: 0%">
                                    <img src="<?php echo e(asset('img/media-arrow-right.svg')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('college/college-navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>