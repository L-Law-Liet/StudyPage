<?php $__env->startSection('title', 'Просмотр города'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Просмотр города</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <table class="table table-striped table-view">
                        <tr>
                            <th>Наименование</th>
                            <td><?php echo e($cityslider->name_ru); ?></td>
                        </tr>
                        <tr>
                            <th>Анонс</th>
                            <td><?php echo e($cityslider->announce); ?></td>
                        </tr>
                        <tr>
                            <th>Изображение</th>
                            <td><img src="/img/cities/<?php echo e($cityslider->image); ?>" alt="<?php echo e($cityslider->name_ru); ?>" width="100px"></td>
                        </tr>
                        <tr>
                            <th>Описание</th>
                            <td id="description"><?php echo $cityslider->description; ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>