<?php $__env->startSection('title', $city->s_title); ?>
<?php $__env->startSection('description', $city->s_description); ?>
<?php $__env->startSection('keywords', $city->s_keywords); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <h3 class="text-center"><strong><?php echo e($city->announce); ?></strong></h3>
                
                <div id="description">
                    <?php echo $city->description; ?>

                </div>
            </div>
            <div class="col-md-3 right-block city-menu">
                <ul class="nav flex-column">
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link <?php if($k == $city->id): ?> active <?php endif; ?>" href="/city/view/<?php echo e($k); ?>">
                                <span class="sprites <?php if($k == $city->id): ?> down <?php else: ?> intern <?php endif; ?>"></span><?php echo e($v); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>