<?php $__env->startSection('content'); ?>
    <div class="container">
        <div id="loading-image">
            <div class="justify-content-center d-flex row h-100">
                <img src="<?php echo e(asset('img/loading.gif')); ?>">
            </div>
        </div>
        <div id="Resp" class="row">
        <?php echo $__env->make('filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

    <script>
        $('.chsn').chosen();
        $('body').on('change', '.ajax-filter', function () {
            let arr = [];
            var all = $(".ajax-filter").map(function() {
                arr[$(this).attr('name')] = $(this).val();
            });
            console.log('--------', arr);
            $('#loading-image').show();
            $.ajax({
                type : 'get',
                url : '<?php echo e(url('/ajax-filter', [$page, $query])); ?>',
                data : {'a' : JSON.stringify(Object.assign ( {}, arr ))},
                success:function (data) {
                    // console.log('success!--',data);
                    $('#Resp').html(data);
                },
                complete: function(){
                    $('#loading-image').hide();
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>