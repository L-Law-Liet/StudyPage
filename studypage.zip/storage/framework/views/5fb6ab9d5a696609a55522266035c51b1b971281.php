<?php $__env->startSection('content'); ?>
    <div class="content">
        <table class="table table-striped table-view">
            <tr>
                <th>Шифр специальности</th>
                <td><?php echo e($specialty->cipher); ?></td>
            </tr>
            <tr>
                <th>Наименование</th>
                <td><?php echo e($specialty->name_ru); ?></td>
            </tr>
            
            <tr>
                <th>Сфера обучения</th>
                <td><?php if(is_object($specialty->relSubdirection)): ?><?php echo e($specialty->relSubdirection->name_ru); ?><?php endif; ?></td>
            </tr>
            <tr>
                <th>Профильный предмет</th>
                <td><?php if(is_object($specialty->relSubject)): ?><?php echo e($specialty->relSubject->name_ru); ?><?php endif; ?></td>
            </tr>
            <tr>
                <th>Степень</th>
                <td><?php if(is_object($specialty->relDegree)): ?><?php echo e($specialty->relDegree->name_ru); ?><?php endif; ?></td>
            </tr>
            <tr>
                <th>Срок обучения</th>
                <td><?php echo e($specialty->education_time); ?></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>