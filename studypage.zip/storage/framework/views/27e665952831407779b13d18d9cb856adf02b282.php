<?php $__env->startSection('content'); ?>
    <div class="content">
        <a href="/admin/article/add" class="btn btn-success pull-right">Добавить</a>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th width="2%">#</th>
                    <th>Заголовок</th>
                    <th>Описание</th>
                    <th width="5%" colspan="3" class="text-center">Действие</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($article->firstItem()+$k); ?></td>
                    <td><?php echo e($v->title); ?></td>
                    <td id="description"><?php echo mb_substr($v->description, 0, 200, 'UTF-8'); ?></td>
                    <td>
                        <a href="/admin/article/view/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-eye-open" title="Просмотр"></i>
                        </a>
                    </td>
                    <td>
                        <a href="/admin/article/add/<?php echo e($v->id); ?>">
                            <i class="glyphicon glyphicon-pencil" title="Редактировать"></i>
                        </a>
                    </td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                <td colspan = '2'>Количество <?php echo e($count); ?></td>
                <td colspan = '3' class='text-center'><?php echo e($article->links()); ?></td>
            </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>