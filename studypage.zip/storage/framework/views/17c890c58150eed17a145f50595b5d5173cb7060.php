<?php $__env->startSection('title', 'Просмотр заявки'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Просмотр заявки</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <table class="table table-striped table-view">
                        <tr>
                            <th>Email</th>
                            <td><?php echo e($proposal->email); ?></td>
                        </tr>
                        <tr>
                            <th>Контактный телефон</th>
                            <td><?php echo e($proposal->contact_phone); ?></td>
                        </tr>
                        <tr>
                            <th>Название учебного заведения</th>
                            <td><?php echo $proposal->university_name; ?></td>
                        </tr>
                        <tr>
                            <th>Имя контактного лица</th>
                            <td><?php echo $proposal->contact_name; ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>