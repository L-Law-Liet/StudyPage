<?php $__env->startSection('css'); ?>
    <style>
        body {
            font-family: Futura PT, sans-serif;
        }
        main.mt-5 {
            margin-top: 0 !important;
        }
        main.py-4 {
            padding-top: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div id="college-view-right">
            <div>
                <h3 class="text-center">По результатам теста Ваш балл составляет: <b><?php echo e($score); ?></b></h3>
            </div>
            <div>
                <table id="ent-table">
                    <thead>
                    <tr>
                        <td colspan="3" class="ent-td w-75 p-2" >Шансы поступить на грант</td>
                        <td onclick="window.location='<?php echo e(route('result-ent2', [4, encrypt($score), $profs[0], $profs[1]])); ?>'" class="ent-td red-hover w-25 not-33 align-middle clickable-el" rowspan="2">Шансы поступить на платное (<?php echo e(count($sRes[3])); ?>)</td>
                    </tr>
                    <tr>
                        <td onclick="window.location='<?php echo e(route('result-ent2', [1, encrypt($score), $profs[0], $profs[1]])); ?>'" class="ent-td red-hover clickable-el">Высокий (<?php echo e(count($sRes[0])); ?>)</td>
                        <td onclick="window.location='<?php echo e(route('result-ent2', [2, encrypt($score),  $profs[0], $profs[1]])); ?>'" class="ent-td red-hover clickable-el">Средний (<?php echo e(count($sRes[1])); ?>)</td>
                        <td onclick="window.location='<?php echo e(route('result-ent2', [3, encrypt($score), $profs[0], $profs[1]])); ?>'" class="ent-td red-hover clickable-el">Низкий (<?php echo e(count($sRes[2])); ?>)</td>
                    </tr>
                    </thead>
                    <tbody class="ent-tbody">






<?php for($i = 0; $i < 5; $i++): ?>
                    <tr>
                        <td>
                            <?php if(count($sRes[0]) > $i): ?>
                                <?php if($sRes[0][$i]->getCost()): ?>
                             <div class="justify-content-start d-flex">
                                <div class="w-8"><i class="fas fa-graduation-cap"></i></div>
                                 <div>
                                     <b>
                                         <a class="ent-href" href="<?php echo e(route('resToSearch', [$sRes[0][$i]->subdirection_id, $sRes[0][$i]->getCost()->university_id, $profs[0], $profs[1]])); ?>"><?php echo e($sRes[0][$i]->relSubdirection->name_ru); ?></a>
                                     </b>
                                 </div>
                            </div>
                                <div class="d-flex justify-content-start">
                                    <div class="w-8"><i class="fas fa-building"></i></div>
                                    <p class="mb-0">
                                        <span>
                                        <a class="ent-href" href="<?php echo e(route('resToSearch', [$sRes[0][$i]->subdirection_id, $sRes[0][$i]->getCost()->university_id, $profs[0], $profs[1]])); ?>"><?php echo e($sRes[0][$i]->getCost()->relUniversity->name_ru); ?></a>
                                        </span>
                                    </p>
                                </div>
                                    <div class="d-flex justify-content-start">
                                        <div class="w-8"></div>
                                        <div><b>Проходной балл ЕНТ: <?php echo e($sRes[0][$i]->getCost()->passing_score); ?></b></div>
                                    </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                        </td>
                        <td>
                            <?php if(count($sRes[1]) > $i): ?>
                                <?php if($sRes[1][$i]->getCost()): ?>
                              <div class="justify-content-start d-flex">
                                  <div class="w-8"><i class="fas fa-graduation-cap"></i></div>
                                  <div>
                                      <b>
                                          <a class="ent-href" href="<?php echo e(route('resToSearch', [$sRes[1][$i]->subdirection_id, $sRes[1][$i]->getCost()->university_id, $profs[0], $profs[1]])); ?>"><?php echo e($sRes[1][$i]->relSubdirection->name_ru); ?></a>
                                      </b>
                                  </div>
                              </div>
                              <div class="d-flex justify-content-start">
                                  <div class="w-8"><i class="fas fa-building"></i></div>
                                  <p class="mb-0">
                                      <span>
                                        <a class="ent-href" href="<?php echo e(route('resToSearch', [$sRes[1][$i]->subdirection_id, $sRes[1][$i]->getCost()->university_id, $profs[0], $profs[1]])); ?>"><?php echo e($sRes[1][$i]->getCost()->relUniversity->name_ru); ?></a>
                                      </span>
                                  </p>
                              </div>
                                    <div class="d-flex justify-content-start">
                                        <div class="w-8"></div>
                                        <div><b>Проходной балл ЕНТ: <?php echo e($sRes[1][$i]->getCost()->passing_score); ?></b></div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(count($sRes[2]) > $i): ?>
                                <?php if($sRes[2][$i]->getCost()): ?>
                            <div class="justify-content-start d-flex">
                                <div class="w-8"><i class="fas fa-graduation-cap"></i></div>
                                <div>
                                    <b><a class="ent-href" href="<?php echo e(route('resToSearch', [$sRes[2][$i]->subdirection_id, $sRes[2][$i]->getCost()->university_id, $profs[0], $profs[1]])); ?>"><?php echo e($sRes[2][$i]->relSubdirection->name_ru); ?></a></b>
                                </div>
                            </div>
                            <div class="d-flex justify-content-start">
                                <div class="w-8"><i class="fas fa-building"></i></div>
                                <p class="mb-0">
                                    <span>
                                        <a class="ent-href" href="<?php echo e(route('resToSearch', [$sRes[2][$i]->subdirection_id, $sRes[2][$i]->getCost()->university_id, $profs[0], $profs[1]])); ?>"><?php echo e($sRes[2][$i]->getCost()->relUniversity->name_ru); ?></a>
                                    </span>
                                </p>
                            </div>
                                    <div class="d-flex justify-content-start">
                                        <div class="w-8"></div>
                                        <div>
                                            <b>Проходной балл ЕНТ: <?php echo e($sRes[2][$i]->getCost()->passing_score); ?></b>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class=" not-33">
                            <?php if(count($sRes[3]) > $i): ?>
                                <?php if($sRes[3][$i]->getCost()): ?>
                             <div class="justify-content-start d-flex">
                                <div class="w-8"><i class="fas fa-graduation-cap"></i></div>
                                 <div>
                                     <b><a class="ent-href" href="<?php echo e(route('resToSearch', [$sRes[3][$i]->subdirection_id, $sRes[3][$i]->getCost()->university_id, $profs[0], $profs[1]])); ?>"><?php echo e($sRes[3][$i]->relSubdirection->name_ru); ?></a></b>
                                 </div>
                            </div>
                            <div class="d-flex justify-content-start">
                                <div class="w-8"><i class="fas fa-building"></i></div>
                                <p class="mb-0">
                                    <span><a class="ent-href" href="<?php echo e(route('resToSearch', [$sRes[3][$i]->subdirection_id, $sRes[3][$i]->getCost()->university_id, $profs[0], $profs[1]])); ?>"><?php echo e($sRes[3][$i]->getCost()->relUniversity->name_ru); ?></a></span>
                                </p>
                            </div>
                                    <div class="d-flex justify-content-start">
                                        <div class="w-8"></div>
                                        <div><b>Проходной балл на платное: <?php echo e($sRes[3][$i]->getCost()->passing_score); ?></b></div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
<?php endfor; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.ent-href').mouseover(function () {
                console.log($(this).parent().parent().parent());
                $(this).parent().parent().parent().parent().find('.ent-href').css({
                    "color": "#c11800",
                });
            });
            $('.ent-href').mouseout(function () {
                $(this).parent().parent().parent().parent().find('.ent-href').css({
                    "color": "black",
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>