<?php $__env->startSection('css'); ?>
    <style>
        body {
            font-family: Futura PT, sans-serif;
        }
        main.mt-5 {
            margin-top: 0 !important;
        }
        main.py-4 {
            padding-top: 0 !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div id="college-view-right">
            <div>
                <h3 class="text-center">По результатам теста Ваш балл составляет: <b><?php echo e($score); ?></b></h3>
            </div>
            <div>
                <table id="ent-table">
                    <thead>
                    <tr>
                        <td colspan="3" class="ent-td w-75 p-2" >Шансы поступить на грант</td>
                        <td onclick="window.location='<?php echo e(route('result-ent2', [4, encrypt($score), encrypt($profs[0]), encrypt($profs[1])])); ?>'" class="ent-td w-25 not-33 clickable-el" rowspan="2">Шансы поступить на платное (<?php echo e(count($sRes[3])); ?>)</td>
                    </tr>
                    <tr>
                        <td onclick="window.location='<?php echo e(route('result-ent2', [1, encrypt($score), encrypt($profs[0]), encrypt($profs[1])])); ?>'" class="ent-td clickable-el">Высокий (<?php echo e(count($sRes[0])); ?>)</td>
                        <td onclick="window.location='<?php echo e(route('result-ent2', [2, encrypt($score), encrypt($profs[0]), encrypt($profs[1])])); ?>'" class="ent-td clickable-el">Средний (<?php echo e(count($sRes[1])); ?>)</td>
                        <td onclick="window.location='<?php echo e(route('result-ent2', [3, encrypt($score), encrypt($profs[0]), encrypt($profs[1])])); ?>'" class="ent-td clickable-el">Низкий (<?php echo e(count($sRes[2])); ?>)</td>
                    </tr>
                    </thead>
                    <tbody class="ent-tbody">






<?php for($i = 0; $i < 5; $i++): ?>
                    <tr>
                        <td>
                            <?php if(count($sRes[0]) > $i): ?>
                                <?php if($sRes[0][$i]->getCost()): ?>
                             <div class="justify-content-start d-flex">
                                <div class="mr-1"><i class="fas fa-graduation-cap"></i></div><div><b><?php echo e($sRes[0][$i]->relSubdirection->name_ru); ?></b></div>
                            </div>
                                <div class="d-flex justify-content-start">
                                    <div class="mr-1"><i class="fas fa-building"></i></div><p><?php echo e($sRes[0][$i]->getCost()->relUniversity->name_ru); ?></p>
                                </div>

                                <b>Проходной балл: <?php echo e($sRes[0][$i]->getCost()->passing_score); ?></b>
                                    <?php endif; ?>
                                <?php endif; ?>
                        </td>
                        <td>
                            <?php if(count($sRes[1]) > $i): ?>
                                <?php if($sRes[1][$i]->getCost()): ?>
                             <div class="justify-content-start d-flex">
                                <div class="mr-1"><i class="fas fa-graduation-cap"></i></div><div><b> <?php echo e($sRes[1][$i]->relSubdirection->name_ru); ?></b></div>
                            </div>
                            <div class="d-flex justify-content-start">
                                <div class="mr-1"><i class="fas fa-building"></i></div><p><?php echo e($sRes[1][$i]->getCost()->relUniversity->name_ru); ?></p>
                            </div>
                            <b>Проходной балл: <?php echo e($sRes[1][$i]->getCost()->passing_score); ?></b>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(count($sRes[2]) > $i): ?>
                                <?php if($sRes[2][$i]->getCost()): ?>
                            <div class="justify-content-start d-flex">
                                <div class="mr-1"><i class="fas fa-graduation-cap"></i></div><div><b> <?php echo e($sRes[2][$i]->relSubdirection->name_ru); ?></b></div>
                            </div>
                            <div class="d-flex justify-content-start">
                                <div class="mr-1"><i class="fas fa-building"></i></div><p><?php echo e($sRes[2][$i]->getCost()->relUniversity->name_ru); ?></p>
                            </div>
                            <b>Проходной балл: <?php echo e($sRes[2][$i]->getCost()->passing_score); ?></b>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class=" not-33">
                            <?php if(count($sRes[3]) > $i): ?>
                                <?php if($sRes[3][$i]->getCost()): ?>
                             <div class="justify-content-start d-flex">
                                <div class="mr-1"><i class="fas fa-graduation-cap"></i></div><div><b> <?php echo e($sRes[3][$i]->relSubdirection->name_ru); ?></b></div>
                            </div>
                            <div class="d-flex justify-content-start">
                                <div class="mr-1"><i class="fas fa-building"></i></div><p><?php echo e($sRes[3][$i]->getCost()->relUniversity->name_ru); ?></p>
                            </div>
                            <b>Проходной балл: <?php echo e($sRes[3][$i]->getCost()->passing_score); ?></b>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
<?php endfor; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>