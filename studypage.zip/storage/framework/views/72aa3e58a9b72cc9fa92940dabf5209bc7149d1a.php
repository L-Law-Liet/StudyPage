

<?php $__env->startSection('title', 'Просмотр специальности в ВУЗе'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Просмотр специальности в ВУЗе</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a class="btn btn-warning pull-right" href="<?php echo e(URL::previous()); ?>">Назад</a>
                </div>
                <div class="box-body">
                    <table class="table table-striped table-view">
                        <tr>
                            <th>Наименование ВУЗа</th>
                            <td><?php echo e($university->name_ru); ?></td>
                        </tr>
                        <?php if(is_object($cost->relSpecialty)): ?>
                            <tr>
                                <th>Специальность</th>
                                <td><?php echo e($cost->relSpecialty->cipher); ?> - <?php echo e($cost->relSpecialty->name_ru); ?></td>
                            </tr>
                        <?php endif; ?>
                        
                        <tr>
                            <th>Город</th>
                            <td><?php echo e($city->name_ru); ?></td>
                        </tr>
                        <tr>
                            <th>Адрес</th>
                            <td><?php echo e($university->address_ru); ?></td>
                        </tr>
                        
                        <tr>
                            <th>Телефон</th>
                            <td><?php echo e($university->phone); ?></td>
                        </tr>
                        <tr>
                            <th>Краткая информация</th>
                            <td><?php echo e($university->information_ru); ?></td>
                        </tr>
                        <tr>
                            <th>Год</th>
                            <td><?php echo e($cost->year); ?></td>
                        </tr>
                        <tr>
                            <th>Рейтинг специальности</th>
                            <td><?php echo e($cost->rating); ?></td>
                        </tr>
                        <tr>
                            <th>Место</th>
                            <td><?php echo e($cost->total); ?></td>
                        </tr>
                        <tr>
                            <th>Количество грантов на русское отделение</th>
                            <td><?php echo e($cost->number_grants_ru); ?></td>
                        </tr>
                        <tr>
                            <th>Количество грантов на казахское отделение</th>
                            <td><?php echo e($cost->number_grants_kz); ?></td>
                        </tr>
                        <tr>
                            <th>Проходной балл на русское отделение</th>
                            <td><?php echo e($cost->passing_score_ru); ?></td>
                        </tr>
                        <tr>
                            <th>Проходной балл на казахское отделение</th>
                            <td><?php echo e($cost->passing_score_kz); ?></td>
                        </tr>
                        <tr>
                            <th>Проходной балл на платное обучение</th>
                            <td><?php echo e($cost->passing_score); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>